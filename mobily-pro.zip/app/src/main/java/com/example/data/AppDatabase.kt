package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Brand::class,
        Category::class,
        Product::class,
        MaintenanceRequest::class,
        Order::class,
        Coupon::class,
        UserRating::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun dbDao(): DbDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mobilypro_database"
                )
                    .addCallback(AppDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.dbDao())
                }
            }
        }

        suspend fun populateDatabase(dao: DbDao) {
            // Seed Brands
            val brands = listOf("Apple", "Samsung", "Xiaomi", "Oppo", "Realme", "Huawei", "Honor")
            brands.forEach { dao.insertBrand(Brand(name = it)) }

            // Seed Categories
            val categories = listOf(
                Category(name = "هواتف جديدة", iconName = "phone_android"),
                Category(name = "هواتف مستعملة", iconName = "phonelink_setup"),
                Category(name = "سماعات", iconName = "headphones"),
                Category(name = "ساعات ذكية", iconName = "watch"),
                Category(name = "شواحن", iconName = "bolt"),
                Category(name = "باور بانك", iconName = "battery_charging_full"),
                Category(name = "كفرات", iconName = "style"),
                Category(name = "قطع غيار", iconName = "build"),
                Category(name = "ملحقات الألعاب", iconName = "sports_esports"),
                Category(name = "أجهزة لوحية", iconName = "tablet_android")
            )
            categories.forEach { dao.insertCategory(it) }

            // Seed Coupons
            dao.insertCoupon(Coupon(code = "MOBILY10", discountPercent = 10, expiryDate = System.currentTimeMillis() + 86400000 * 30))
            dao.insertCoupon(Coupon(code = "PRO20", discountPercent = 20, expiryDate = System.currentTimeMillis() + 86400000 * 30))

            // Seed Products
            val p1 = Product(
                name = "آيفون 15 برو ماكس",
                brand = "Apple",
                category = "هواتف جديدة",
                price = 5199.0,
                oldPrice = 5799.0,
                discountPercent = 10,
                condition = "جديد",
                imageUrls = "iphone_15_pro_max",
                description = "آيفون 15 برو ماكس الجديد بهيكل قوي وخفيف من التيتانيوم ومستشعر كاميرا رئيسي 48 ميجابكسل وشريحة A17 Pro المذهلة للألعاب الصعبة.",
                features = "تصميم تيتانيوم متين|شريحة A17 Pro فائقة السرعة|كاميرا تليسكوب بـ 5x تقريب بصري|منفذ USB-C حديث ومريح",
                disadvantages = "السعر مرتفع جداً|لا يتوفر الشاحن في العلبة|سرعة الشحن لا تزال محدودة مقارنة بالمنافسين",
                specs = "الشاشة:6.7 بوصة Super Retina XDR|المعالج:A17 Pro|الذاكرة العشوائية:8 جيجا بايت|التخزين:256 جيجا بايت",
                rating = 4.9f,
                reviewCount = 124,
                stockQuantity = 15,
                isPopular = true,
                isLightningDeal = true,
                lightningEndTime = System.currentTimeMillis() + 86400000 // 24 hours
            )

            val p2 = Product(
                name = "سامسونج جالكسي S24 الترا",
                brand = "Samsung",
                category = "هواتف جديدة",
                price = 4599.0,
                oldPrice = 5299.0,
                discountPercent = 13,
                condition = "جديد",
                imageUrls = "samsung_s24_ultra",
                description = "قوة الذكاء الاصطناعي Galaxy AI بين يديك. كاميرا 200 ميجابكسل ذات تفاصيل مذهلة، وقلم S-Pen مدمج لتدوين ملاحظاتك بسهولة، مع شاشة مسطحة مريحة للعين.",
                features = "دعم كامل لمزايا الذكاء الاصطناعي|شاشة ساطعة للغاية ومقاومة للانعكاس|كاميرا 200 ميجابكسل فائقة التفاصيل|قلم S-Pen مدمج ورائع",
                disadvantages = "وزن الهاتف ثقيل نسبياً|حجم الهاتف عريض للمسكة المفردة|سرعة الشحن 45 واط فقط",
                specs = "الشاشة:6.8 بوصة Dynamic AMOLED 2X|المعالج:Snapdragon 8 Gen 3|الذاكرة العشوائية:12 جيجا بايت|التخزين:512 جيجا بايت",
                rating = 4.8f,
                reviewCount = 98,
                stockQuantity = 20,
                isPopular = true,
                isLightningDeal = false
            )

            val p3 = Product(
                name = "آيفون 14 برو (مستعمل كالمستجد)",
                brand = "Apple",
                category = "هواتف مستعملة",
                price = 3300.0,
                oldPrice = 4200.0,
                discountPercent = 21,
                condition = "مستعمل",
                imageUrls = "iphone_14_pro_used",
                description = "جهاز آيفون 14 برو مستعمل خفيف بحالة ممتازة جداً. بدون خدوش على الشاشة مع ضمان المتجر المعتمد.",
                features = "الجزيرة التفاعلية Dynamic Island|شاشة بميزة Always-On|أداء ممتاز مع معالج A16 Bionic|حالة البطارية ممتازة",
                disadvantages = "الهيكل يحتوي على خدوش مجهرية لا تذكر|بدون العلبة الأصلية أحياناً",
                specs = "الشاشة:6.1 بوصة Super Retina XDR|المعالج:A16 Bionic|الذاكرة العشوائية:6 جيجا بايت|التخزين:128 جيجا بايت|صحة البطارية:91%",
                rating = 4.5f,
                reviewCount = 42,
                batteryHealth = 91,
                screenStatus = "سليمة 100% وخالية من الخدوش",
                bodyStatus = "ممتازة (ممتاز) مع خدوش طفيفة جداً بالاطار السفلي",
                usageDuration = "7 أشهر",
                testReport = "تم فحص جميع المستشعرات، زر الهوم وكاميرات التقريب والبطارية بنجاح تام، أداء مستقر 100%.",
                conditionGrade = "ممتاز",
                stockQuantity = 3,
                isPopular = false,
                isLightningDeal = false
            )

            val p4 = Product(
                name = "جالكسي S23 الترا (مستعمل بحالة جيدة جداً)",
                brand = "Samsung",
                category = "هواتف مستعملة",
                price = 2850.0,
                oldPrice = 3800.0,
                discountPercent = 25,
                condition = "مستعمل",
                imageUrls = "samsung_s23_ultra_used",
                description = "سامسونج جالكسي اس 23 الترا مستعمل في حالة نظيفة جداً (اصدار 256 جيجا). يأتي مع قلم الشاشة الأصلي، خالي من العيوب الفنية تماماً.",
                features = "بطارية تدوم طويلاً جداً|صناعة من الألومنيوم المتين|زووم وتقريب هجين يعيد تعريف الكاميرات|أداء ممتاز جداً للألعاب",
                disadvantages = "عمر بطارية مستهلك جزئياً بنسبة بسيطة|يوجد خدوش بسيطة جداً بالظهر",
                specs = "الشاشة:6.8 بوصة Dynamic AMOLED|المعالج:Snapdragon 8 Gen 2|الذاكرة العشوائية:8 جيجا بايت|التخزين:256 جيجا بايت|صحة البطارية:88%",
                rating = 4.6f,
                reviewCount = 19,
                batteryHealth = 88,
                screenStatus = "سليمة بالكامل مع لاصقة حماية",
                bodyStatus = "نظيف جداً (جيد جداً) لا وجود لضربات قوية",
                usageDuration = "10 أشهر",
                testReport = "تقرير الفحص: الفحص الفني أكد سلامة الميكروفونات والواي فاي والـ GPS ومستشعر بصمة الاصبع، أداء سليم تماماً.",
                conditionGrade = "جيد جداً",
                stockQuantity = 2,
                isPopular = false,
                isLightningDeal = true,
                lightningEndTime = System.currentTimeMillis() + 86400000 // 24 hours
            )

            val p5 = Product(
                name = "سماعة آبل إيربودز برو 2 الجيل الثاني",
                brand = "Apple",
                category = "سماعات",
                price = 849.0,
                oldPrice = 1099.0,
                discountPercent = 22,
                condition = "جديد",
                imageUrls = "airpods_pro_2",
                description = "الجيل الثاني من سماعات إيربودز برو الرائعة مع ميزة إلغاء الضجيج النشط المضاعفة والشفافية التكيفية الفائقة.",
                features = "إلغاء الضجيج نشط مميز|صوت نقي ثلاثي الأبعاد|علبة شحن مزودة بمكبر صوت مدمج للعثور عليها|مقاومة للعرق والماء",
                disadvantages = "التحكم في الصوت يتطلب بعض الممارسة|ملائمة الأذن قد تتفاوت حسب حجم قطع السيليكون",
                specs = "شريحة الصوت:Apple H2|علبة الشحن:منفذ USB-C مع مكبر صوت مدمج|عمر البطارية:تصل إلى 6 ساعات شحنة واحدة",
                rating = 4.9f,
                reviewCount = 155,
                stockQuantity = 30,
                isPopular = true,
                isLightningDeal = false
            )

            val p6 = Product(
                name = "شاحن أنكر نانو 3 بقوة 30 واط",
                brand = "Xiaomi",
                category = "شواحن",
                price = 69.0,
                oldPrice = 99.0,
                discountPercent = 30,
                condition = "جديد",
                imageUrls = "anker_nano_3",
                description = "شاحن أنكر نانو 3 فائق الصغر بقوة 30 واط لشحن الآيفون والآيباد والأندرويد بأقصى سرعة أمان وموثوقية عالية.",
                features = "حجم صغير جداً وخفيف الوزن|دعم الشحن السريع PD 3.0|آمن بالكامل مع أنظمة ذكية لحماية البطارية|شحن الأجهزة اللوحية بكفاءة",
                disadvantages = "منفذ تايب سي واحد فقط|لا يأتي مع كيبل الشحن بالعلبة",
                specs = "القوة:30 واط|المنفذ:USB-C PD|الحجم:متقارب جداً مع كعب شاحن 5 واط القديم",
                rating = 4.7f,
                reviewCount = 210,
                stockQuantity = 50,
                isPopular = false,
                isLightningDeal = false
            )

            val p7 = Product(
                name = "ساعة شاومي ريدمي ووتش 4 الذكية",
                brand = "Xiaomi",
                category = "ساعات ذكية",
                price = 349.0,
                oldPrice = 449.0,
                discountPercent = 22,
                condition = "جديد",
                imageUrls = "redmi_watch_4",
                description = "ساعة ريدمي 4 بشاشة ممتازة جداً وألوان ساطعة وعمر بطارية يتخطى 14 يوم ومستشعرات دقيقة لنبضات القلب والرياضة والنوم البشري.",
                features = "شاشة AMOLED كبيرة الحجم 1.97 بوصة|عمر بطارية خرافي يصل لـ 14 يوم|دعم المكالمات عبر البلوتوث بوضوح|نظام تتبع رياضي متكامل وجاهز",
                disadvantages = "التطبيق الخاص بها يحتاج تحسينات بسيطة|لا تدعم إضافة التطبيقات الخارجية مثل ابل وسامسونج",
                specs = "الشاشة:1.97 بوصة AMOLED|البطارية:470 مللي أمبير|مقاومة الماء:5ATM",
                rating = 4.4f,
                reviewCount = 49,
                stockQuantity = 12,
                isPopular = false,
                isLightningDeal = false
            )

            dao.insertProduct(p1)
            dao.insertProduct(p2)
            dao.insertProduct(p3)
            dao.insertProduct(p4)
            dao.insertProduct(p5)
            dao.insertProduct(p6)
            dao.insertProduct(p7)

            // Seed some default User Ratings
            dao.insertRating(UserRating(productId = 1, userName = "أحمد خالد", rating = 5, comment = "جهاز جبار وسعر ممتاز لدى موبايلي برو والتوصيل كان في غضون ٢٤ ساعة فقط! شكراً لكم"))
            dao.insertRating(UserRating(productId = 1, userName = "سارة أحمد", rating = 5, comment = "اللون التيتانيوم الطبيعي نخب مميز وأصلي ١٠٠٪ والتعامل قمة في الرقي والمصداقية."))
            dao.insertRating(UserRating(productId = 3, userName = "فيصل محمد", rating = 4, comment = "الجهاز المستعمل نظيف فعلياً والبطارية فوق ٩٠٪. الضمان يعطي ثقة كبيرة في الشراء والتعامل"))
        }
    }
}

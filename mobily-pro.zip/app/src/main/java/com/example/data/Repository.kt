package com.example.data

import kotlinx.coroutines.flow.Flow

class Repository(private val dbDao: DbDao) {

    // --- Products ---
    val allProducts: Flow<List<Product>> = dbDao.getAllProducts()
    val lightningDeals: Flow<List<Product>> = dbDao.getLightningDeals()

    suspend fun getProductById(id: Int): Product? = dbDao.getProductById(id)

    suspend fun insertProduct(product: Product): Long = dbDao.insertProduct(product)

    suspend fun updateProduct(product: Product) = dbDao.updateProduct(product)

    suspend fun deleteProduct(product: Product) = dbDao.deleteProduct(product)

    // --- Brands ---
    val allBrands: Flow<List<Brand>> = dbDao.getAllBrands()

    suspend fun insertBrand(brand: Brand) = dbDao.insertBrand(brand)

    suspend fun deleteBrand(brand: Brand) = dbDao.deleteBrand(brand)

    // --- Categories ---
    val allCategories: Flow<List<Category>> = dbDao.getAllCategories()

    suspend fun insertCategory(category: Category) = dbDao.insertCategory(category)

    suspend fun deleteCategory(category: Category) = dbDao.deleteCategory(category)

    // --- MaintenanceRequests ---
    val allMaintenanceRequests: Flow<List<MaintenanceRequest>> = dbDao.getAllMaintenanceRequests()

    suspend fun getMaintenanceByTracking(reqNum: String, phone: String): MaintenanceRequest? =
        dbDao.getMaintenanceByTracking(reqNum, phone)

    suspend fun insertMaintenance(request: MaintenanceRequest): Long =
        dbDao.insertMaintenance(request)

    suspend fun updateMaintenance(request: MaintenanceRequest) =
        dbDao.updateMaintenance(request)

    suspend fun deleteMaintenance(request: MaintenanceRequest) =
        dbDao.deleteMaintenance(request)

    // --- Orders ---
    val allOrders: Flow<List<Order>> = dbDao.getAllOrders()

    suspend fun insertOrder(order: Order): Long = dbDao.insertOrder(order)

    suspend fun updateOrder(order: Order) = dbDao.updateOrder(order)

    suspend fun deleteOrder(order: Order) = dbDao.deleteOrder(order)

    // --- Coupons ---
    val allCoupons: Flow<List<Coupon>> = dbDao.getAllCoupons()

    suspend fun getCouponByCode(code: String): Coupon? = dbDao.getCouponByCode(code)

    suspend fun insertCoupon(coupon: Coupon) = dbDao.insertCoupon(coupon)

    suspend fun deleteCoupon(coupon: Coupon) = dbDao.deleteCoupon(coupon)

    // --- User Ratings ---
    val allRatings: Flow<List<UserRating>> = dbDao.getAllRatings()

    fun getRatingsForProduct(productId: Int): Flow<List<UserRating>> =
        dbDao.getRatingsForProduct(productId)

    suspend fun insertRating(rating: UserRating) = dbDao.insertRating(rating)

    suspend fun updateRating(rating: UserRating) = dbDao.updateRating(rating)

    suspend fun deleteRating(rating: UserRating) = dbDao.deleteRating(rating)
}

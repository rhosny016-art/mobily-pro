package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "brands")
data class Brand(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val iconName: String
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val brand: String,
    val category: String,
    val price: Double,
    val oldPrice: Double,
    val discountPercent: Int,
    val condition: String, // "جديد" or "مستعمل"
    val imageUrls: String, // comma-separated strings of image descriptors or local assets
    val description: String,
    val features: String, // split by | or commas
    val disadvantages: String, // split by | or commas
    val specs: String, // key:value|key:value format
    val rating: Float,
    val reviewCount: Int,
    val batteryHealth: Int? = null, // for used
    val screenStatus: String? = null, // for used
    val bodyStatus: String? = null, // for used
    val usageDuration: String? = null, // for used
    val testReport: String? = null, // for used
    val conditionGrade: String? = null, // "ممتاز" or "جيد جداً" or "جيد"
    val stockQuantity: Int = 10,
    val isPopular: Boolean = false,
    val isLightningDeal: Boolean = false,
    val lightningEndTime: Long? = null
)

@Entity(tableName = "maintenance_requests")
data class MaintenanceRequest(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val requestNumber: String, // MP-xxxxxx
    val clientName: String,
    val clientPhone: String,
    val deviceBrand: String,
    val deviceModel: String,
    val issueDescription: String,
    val issueType: String, // كسر شاشة، بطارية، مشكلة شحن، إلخ
    val urgency: String, // عاجل جداً، عاجل، عادي
    val status: String, // تم الاستلام، تحت الفحص، جاري الإصلاح، إلخ
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val orderNumber: String, // OD-xxxxxx
    val clientName: String,
    val clientPhone: String,
    val clientProvince: String,
    val clientCity: String,
    val clientAddress: String,
    val paymentMethod: String = "الدفع عند الاستلام",
    val couponCode: String? = null,
    val shippingCost: Double = 0.0,
    val totalAmount: Double,
    val status: String, // قيد المراجعة، تم التأكيد، جاري الشحن، تم التوصيل
    val itemsJson: String, // Product names and quantities
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "coupons")
data class Coupon(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val code: String,
    val discountPercent: Int,
    val expiryDate: Long
)

@Entity(tableName = "user_ratings")
data class UserRating(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productId: Int,
    val userName: String,
    val rating: Int,
    val comment: String,
    val imageUrls: String? = null, // if any
    val isApproved: Boolean = true,
    val date: Long = System.currentTimeMillis()
)

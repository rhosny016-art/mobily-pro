package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DbDao {

    // --- Products ---
    @Query("SELECT * FROM products ORDER BY id DESC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getProductById(id: Int): Product?

    @Query("SELECT * FROM products WHERE isLightningDeal = 1")
    fun getLightningDeals(): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product): Long

    @Update
    suspend fun updateProduct(product: Product)

    @Delete
    suspend fun deleteProduct(product: Product)

    // --- Brands ---
    @Query("SELECT * FROM brands ORDER BY name ASC")
    fun getAllBrands(): Flow<List<Brand>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBrand(brand: Brand)

    @Delete
    suspend fun deleteBrand(brand: Brand)

    // --- Categories ---
    @Query("SELECT * FROM categories")
    fun getAllCategories(): Flow<List<Category>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: Category)

    @Delete
    suspend fun deleteCategory(category: Category)

    // --- MaintenanceRequests ---
    @Query("SELECT * FROM maintenance_requests ORDER BY id DESC")
    fun getAllMaintenanceRequests(): Flow<List<MaintenanceRequest>>

    @Query("SELECT * FROM maintenance_requests WHERE requestNumber = :reqNum AND clientPhone = :phone LIMIT 1")
    suspend fun getMaintenanceByTracking(reqNum: String, phone: String): MaintenanceRequest?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaintenance(request: MaintenanceRequest): Long

    @Update
    suspend fun updateMaintenance(request: MaintenanceRequest)

    @Delete
    suspend fun deleteMaintenance(request: MaintenanceRequest)

    // --- Orders ---
    @Query("SELECT * FROM orders ORDER BY id DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order): Long

    @Update
    suspend fun updateOrder(order: Order)

    @Delete
    suspend fun deleteOrder(order: Order)

    // --- Coupons ---
    @Query("SELECT * FROM coupons")
    fun getAllCoupons(): Flow<List<Coupon>>

    @Query("SELECT * FROM coupons WHERE code = :code LIMIT 1")
    suspend fun getCouponByCode(code: String): Coupon?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCoupon(coupon: Coupon)

    @Delete
    suspend fun deleteCoupon(coupon: Coupon)

    // --- User Ratings ---
    @Query("SELECT * FROM user_ratings WHERE productId = :productId ORDER BY id DESC")
    fun getRatingsForProduct(productId: Int): Flow<List<UserRating>>

    @Query("SELECT * FROM user_ratings ORDER BY id DESC")
    fun getAllRatings(): Flow<List<UserRating>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRating(rating: UserRating)

    @Update
    suspend fun updateRating(rating: UserRating)

    @Delete
    suspend fun deleteRating(rating: UserRating)
}

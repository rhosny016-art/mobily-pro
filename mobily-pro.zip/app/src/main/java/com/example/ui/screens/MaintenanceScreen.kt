package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MaintenanceRequest
import com.example.ui.MainViewModel
import com.example.ui.theme.frostedGlass

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaintenanceScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val trackedRequest by viewModel.trackedRequest.collectAsState()
    val trackingSearchCompleted by viewModel.trackingSearchCompleted.collectAsState()

    var activeTabIdx by remember { mutableStateOf(0) } // 0: طلب صيانة جديدة, 1: تتبع حالة الصيانة

    // Form inputs state
    var clientName by remember { mutableStateOf("") }
    var clientPhone by remember { mutableStateOf("") }
    var deviceBrand by remember { mutableStateOf("") }
    var deviceModel by remember { mutableStateOf("") }
    var selectedFault by remember { mutableStateOf("كسر شاشة") }
    var issueText by remember { mutableStateOf("") }
    var urgencyLevel by remember { mutableStateOf("عادي") } // عاجل جداً, عاجل, عادي

    // Simulation of photo attachment
    var attachmentUploaded by remember { mutableStateOf(false) }

    // Search inputs
    var searchPhone by remember { mutableStateOf("") }
    var searchReqNum by remember { mutableStateOf("") }

    val commonFaults = listOf(
        "كسر شاشة", "بطارية", "مشكلة شحن", "سوفت وير", "شبكة",
        "كاميرا", "سماعة", "تضرر بالماء", "فك حساب قفل", "عطل آخر"
    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("قسم الصيانة الاحترافية", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Elegant Tab indicator
            TabRow(selectedTabIndex = activeTabIdx) {
                Tab(
                    selected = activeTabIdx == 0,
                    onClick = { activeTabIdx = 0 },
                    text = { Text("طلب صيانة جديدة", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = activeTabIdx == 1,
                    onClick = { activeTabIdx = 1 },
                    text = { Text("تتبع طلب صيانة قائم", fontWeight = FontWeight.Bold) }
                )
            }

            AnimatedContent(
                targetState = activeTabIdx,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                label = "Tab animation"
            ) { index ->
                if (index == 0) {
                    // New Maintenance Form
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .frostedGlass(RoundedCornerShape(20.dp)),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text("سجل هاتف للبدء بالصيانة المضمونة", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)

                                OutlinedTextField(
                                    value = clientName,
                                    onValueChange = { clientName = it },
                                    label = { Text("الاسم الكامل") },
                                    leadingIcon = { Icon(imageVector = Icons.Default.Person, contentDescription = null) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("maint_name_input")
                                )

                                OutlinedTextField(
                                    value = clientPhone,
                                    onValueChange = { clientPhone = it },
                                    label = { Text("رقم الهاتف") },
                                    leadingIcon = { Icon(imageVector = Icons.Default.Phone, contentDescription = null) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("maint_phone_input")
                                )

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    OutlinedTextField(
                                        value = deviceBrand,
                                        onValueChange = { deviceBrand = it },
                                        label = { Text("نوع الجهاز (مثال: Apple)") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f).testTag("maint_brand_input")
                                    )

                                    OutlinedTextField(
                                        value = deviceModel,
                                        onValueChange = { deviceModel = it },
                                        label = { Text("موديل الجهاز (مثال: iPhone 15)") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f).testTag("maint_model_input")
                                    )
                                }

                                // Common faults selector grid/chips
                                Column {
                                    Text("الأعطال الشائعة", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(bottom = 6.dp))
                                    FlowLayoutForFaults(
                                        faults = commonFaults,
                                        selected = selectedFault,
                                        onSelect = { selectedFault = it }
                                    )
                                }

                                OutlinedTextField(
                                    value = issueText,
                                    onValueChange = { issueText = it },
                                    label = { Text("وصف المشكلة بالتفصيل") },
                                    minLines = 3,
                                    modifier = Modifier.fillMaxWidth().testTag("maint_desc_input")
                                )

                                // Urgency selection dropdown representation
                                Text("درجة الاستعجال", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    listOf("عاجل جداً", "عاجل", "عادي").forEach { level ->
                                        ElevatedFilterChip(
                                            selected = urgencyLevel == level,
                                            onClick = { urgencyLevel = level },
                                            label = { Text(level) },
                                            colors = FilterChipDefaults.elevatedFilterChipColors(
                                                selectedContainerColor = if (level == "عاجل جداً") Color(0xFFE53935) else if (level == "عاجل") Color(0xFFFF8F00) else MaterialTheme.colorScheme.primary,
                                                selectedLabelColor = Color.White
                                            ),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }

                                // Upload Simulation
                                Button(
                                    onClick = {
                                        attachmentUploaded = true
                                        Toast.makeText(context, "تمت محاكاة رفع صورة العطل بنجاح!", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f),
                                        contentColor = MaterialTheme.colorScheme.secondary
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(imageVector = if (attachmentUploaded) Icons.Default.Check else Icons.Default.Attachment, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(if (attachmentUploaded) "تم إرفاق صورة العطل (صورة_عطل.jpg)" else "إرفاق صورة أو فيديو للعطل (اختياري)", fontSize = 12.sp)
                                }
                            }
                        }

                        // Submit Button
                        Button(
                            onClick = {
                                if (clientName.isEmpty() || clientPhone.isEmpty() || deviceBrand.isEmpty()) {
                                    Toast.makeText(context, "الرجاء تعبئة الاسم ورقم الهاتف ونوع الجهاز", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.submitMaintenanceRequest(
                                        name = clientName,
                                        phone = clientPhone,
                                        brand = deviceBrand,
                                        model = deviceModel,
                                        issueType = selectedFault,
                                        description = issueText,
                                        urgency = urgencyLevel
                                    ) { reqNum ->
                                        // Trigger Success dialog & potential WhatsApp routing
                                        val message = """
                                            📋 *طلب صيانة جديد - موبايلي برو*
                                            *رقم الطلب:* $reqNum
                                            *الاسم:* $clientName
                                            *رقم الهاتف:* $clientPhone
                                            *الجهاز:* $deviceBrand $deviceModel
                                            *النوع العطل:* $selectedFault
                                            *المستعجلية:* $urgencyLevel
                                            *الوصف:* $issueText
                                        """.trimIndent()

                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/966512345678?text=${Uri.encode(message)}"))
                                        try {
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            // Fallback
                                        }

                                        Toast.makeText(context, "تم تسجيل طلب الصيانة بنجاح برقم $reqNum وتم نسخ تفاصيل الطلب لإرسالها بالواتساب!", Toast.LENGTH_LONG).show()
                                        // Reset fields
                                        clientName = ""
                                        clientPhone = ""
                                        deviceBrand = ""
                                        deviceModel = ""
                                        issueText = ""
                                        attachmentUploaded = false
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("submit_maint_request_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("تسجيل وإرسال الطلب للواتساب 📱", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    // Tracking Existing Maintenance Request
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .frostedGlass(RoundedCornerShape(20.dp)),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text("استعلم عن حالة جهازك بورشة الصيانة", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)

                                OutlinedTextField(
                                    value = searchPhone,
                                    onValueChange = { searchPhone = it },
                                    label = { Text("رقم هاتف العميل المسجل") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("track_phone_input")
                                )

                                OutlinedTextField(
                                    value = searchReqNum,
                                    onValueChange = { searchReqNum = it },
                                    label = { Text("رقم طلب الصيانة (مثال: MP-123456)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("track_req_input")
                                )

                                Button(
                                    onClick = {
                                        if (searchPhone.isNotEmpty() && searchReqNum.isNotEmpty()) {
                                            viewModel.trackMaintenance(searchPhone, searchReqNum)
                                        } else {
                                            Toast.makeText(context, "فضلاً، املأ حقل الهاتف وحقل رقم الطلب أولاً", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("track_search_btn"),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("ابحث واستعلم 🔍", fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Display search details
                        if (trackingSearchCompleted) {
                            if (trackedRequest == null) {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                                ) {
                                    Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                                        Text(
                                            "عذراً، لم نجد أي طلب صيانة يطابق هذا الهاتف وهذا الرقم. تأكد من صحة المدخلات وجرب مجدداً.",
                                            color = Color(0xFFC62828),
                                            textAlign = TextAlign.Center,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            } else {
                                val req = trackedRequest!!
                                TrackingFlowStepper(req)
                            }
                        }
                    }
                }
            }
        }
    }
}

// FlowLayout helper for faults chips
@Composable
fun FlowLayoutForFaults(
    faults: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        val rows = faults.chunked(3)
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { fault ->
                    ElevatedFilterChip(
                        selected = selectAndMatch(selected, fault),
                        onClick = { onSelect(fault) },
                        label = { Text(fault, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

fun selectAndMatch(s1: String, s2: String): Boolean = s1 == s2

@Composable
fun TrackingFlowStepper(req: MaintenanceRequest) {
    val states = listOf(
        "تم الاستلام",
        "تحت الفحص",
        "جاري الإصلاح",
        "بانتظار قطعه غيار",
        "تم الإصلاح",
        "جاهز للاستلام",
        "تم التسليم"
    )

    val currentIdx = states.indexOf(req.status).coerceAtLeast(0)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .frostedGlass(RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                text = "تفاصيل طلب الصيانة: ${req.requestNumber}",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Right
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الموديل: ${req.deviceBrand} ${req.deviceModel}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text("نوع العطل: ${req.issueType}", fontSize = 12.sp)
            }

            Text("وصف العطل: ${req.issueDescription}", fontSize = 11.sp, color = Color.Gray, lineHeight = 16.sp)

            Divider(color = MaterialTheme.colorScheme.outlineVariant)

            // Dynamic Progress Indicator
            Text("مرحلة تقدم عملية الإصلاح:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                states.forEachIndexed { idx, stateName ->
                    val isCompleted = idx <= currentIdx
                    val isCurrent = idx == currentIdx

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Colored circle indicator
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(
                                    color = if (isCompleted) MaterialTheme.colorScheme.primary else Color.LightGray,
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCompleted) {
                                Icon(
                                    imageVector = if (isCurrent) Icons.Default.Cached else Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }

                        Text(
                            text = stateName,
                            fontSize = 13.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                            color = if (isCurrent) MaterialTheme.colorScheme.primary else if (isCompleted) MaterialTheme.colorScheme.onSurface else Color.LightGray,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Right
                        )
                    }
                }
            }
        }
    }
}

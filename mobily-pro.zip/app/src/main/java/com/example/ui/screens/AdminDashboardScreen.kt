package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val products by viewModel.products.collectAsState()
    val brands by viewModel.brands.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val maintenanceRequests by viewModel.maintenanceRequests.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val coupons by viewModel.coupons.collectAsState()

    var activeAdminTab by remember { mutableStateOf(0) } // 0: الإحصائيات, 1: إدارة المنتجات, 2: المبيعات والصيانة, 3: الإعدادات والكوبونات

    // Form product dialog state
    var showAddProdDialog by remember { mutableStateOf(false) }
    var newProdName by remember { mutableStateOf("") }
    var newProdBrand by remember { mutableStateOf("Apple") }
    var newProdCategory by remember { mutableStateOf("هواتف جديدة") }
    var newProdPrice by remember { mutableStateOf("") }
    var newProdOldPrice by remember { mutableStateOf("") }
    var newProdCond by remember { mutableStateOf("جديد") }
    var newProdDesc by remember { mutableStateOf("") }
    var newProdFeat by remember { mutableStateOf("") }
    var newProdDis by remember { mutableStateOf("") }
    var newProdSpecs by remember { mutableStateOf("") }
    var newProdStock by remember { mutableStateOf("10") }

    // Brand and Category add states
    var newBrandName by remember { mutableStateOf("") }
    var newCatName by remember { mutableStateOf("") }

    // Coupon manage states
    var newCouponCode by remember { mutableStateOf("") }
    var newCouponDiscount by remember { mutableStateOf("15") }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("لوحة تحكم الإدارة الكاملة", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = MaterialTheme.colorScheme.primary
                ),
                actions = {
                    IconButton(onClick = { viewModel.isAdminLoggedIn.value = false }) {
                        Icon(imageVector = Icons.Default.Logout, contentDescription = "Exit Admin", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Horizontal Admin tabs
            ScrollableTabRow(selectedTabIndex = activeAdminTab) {
                listOf("📊 الإحصائيات", "📦 المنتجات", "🛠️ الطلبات والصيانة", "⚙️ الإعدادات والكوبونات").forEachIndexed { idx, title ->
                    Tab(
                        selected = activeAdminAdminTab(activeAdminTab, idx),
                        onClick = { activeAdminTab = idx },
                        text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    )
                }
            }

            AnimatedContent(
                targetState = activeAdminTab,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                label = "Admin subtabs animation"
            ) { subIndex ->
                when (subIndex) {
                    0 -> {
                        // Statistics Dashboard Panel
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text("التقرير المالي الفوري للمبيعات والصيانة", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                            val totalRevenue = orders.sumOf { it.totalAmount }

                            // Numerical cards row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                StatCard(
                                    title = "عدد المبيعات",
                                    value = "${orders.size} طلب",
                                    icon = Icons.Default.TrendingUp,
                                    bgColor = Color(0xFFE8F5E9),
                                    textColor = Color(0xFF2E7D32),
                                    modifier = Modifier.weight(1f)
                                )


                                StatCard(
                                    title = "إجمالي المبيعات",
                                    value = "${String.format("%.1f", totalRevenue)} ر.س",
                                    icon = Icons.Default.MonetizationOn,
                                    bgColor = Color(0xFFE3F2FD),
                                    textColor = Color(0xFF1565C0),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val profitNet = totalRevenue * 0.15 + (maintenanceRequests.size * 120.0)
                                StatCard(
                                    title = "أرباح الشهر المتوقعة",
                                    value = "${String.format("%.1f", profitNet)} ر.س",
                                    icon = Icons.Default.PieChart,
                                    bgColor = Color(0xFFFFF3E0),
                                    textColor = Color(0xFFE65100),
                                    modifier = Modifier.weight(1f)
                                )

                                StatCard(
                                    title = "طلبات الصيانة",
                                    value = "${maintenanceRequests.size} هاتف",
                                    icon = Icons.Default.Construction,
                                    bgColor = Color(0xFFF3E5F5),
                                    textColor = Color(0xFF7B1FA2),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Divider()

                            // List of low Stock signals
                            Text("🚨 تنبيهات وتحذيرات المخزون المنخفض:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            val lowStockProducts = products.filter { it.stockQuantity <= 3 }
                            if (lowStockProducts.isEmpty()) {
                                Text("ممتاز! مخزون المنتجات سليم ولا يستوجب الشحن الفوري حالياً.", color = Color.Gray, fontSize = 11.sp)
                            } else {
                                lowStockProducts.forEach { item ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("المتوفر: ${item.stockQuantity} فقط!", fontWeight = FontWeight.Bold, color = Color.Red, fontSize = 11.sp)
                                            Text(item.name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        // Product and Catalog Management
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = { showAddProdDialog = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("admin_add_prod_btn"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إضافة منتج جديد للمتجر")
                            }

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(products) { item ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            IconButton(onClick = { viewModel.deleteProduct(item) }) {
                                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove", tint = Color.Red)
                                            }

                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("${item.price} ر.س", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                                                Text("المخزون: ${item.stockQuantity}", fontSize = 10.sp, color = Color.Gray)
                                            }

                                            Column(
                                                modifier = Modifier.weight(1f),
                                                horizontalAlignment = Alignment.End
                                            ) {
                                                Text(item.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                                                Text("فئة: ${item.category} | ${item.brand}", fontSize = 10.sp, color = Color.LightGray)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // Active client orders & maintenance workflow status
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Client Purchase Orders
                            Text("🛒 طلبات الشراء الواردة من العملاء (${orders.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            if (orders.isEmpty()) {
                                Text("لا توجد طلبات شراء مسجلة حالياً.", color = Color.Gray, fontSize = 12.sp)
                            } else {
                                orders.forEach { order ->
                                    var orderMenuExpanded by remember { mutableStateOf(false) }
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Box {
                                                    Button(
                                                        onClick = { orderMenuExpanded = true },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), contentColor = MaterialTheme.colorScheme.primary),
                                                        shape = RoundedCornerShape(4.dp)
                                                    ) {
                                                        Text("تعديل حالة: ${order.status}", fontSize = 10.sp)
                                                    }

                                                    DropdownMenu(expanded = orderMenuExpanded, onDismissRequest = { orderMenuExpanded = false }) {
                                                        listOf("قيد المراجعة", "تم التأكيد", "جاري الشحن", "تم التوصيل").forEach { s ->
                                                            DropdownMenuItem(
                                                                text = { Text(s, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
                                                                onClick = {
                                                                    viewModel.updateOrderStatus(order, s)
                                                                    orderMenuExpanded = false
                                                                }
                                                            )
                                                        }
                                                    }
                                                }

                                                Text("الرقم: ${order.orderNumber}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                            }

                                            Text("اسم العميل: ${order.clientName}", fontSize = 12.sp)
                                            Text("الهاتف: ${order.clientPhone}", fontSize = 12.sp)
                                            Text("العنوان: ${order.clientProvince} - ${order.clientCity}، ${order.clientAddress}", fontSize = 11.sp, color = Color.Gray)
                                            Text("العناصر: ${order.itemsJson}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
                                            Text("المجموع النهائي: ${order.totalAmount} ر.س", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)

                                            IconButton(
                                                onClick = { viewModel.deleteOrder(order) },
                                                modifier = Modifier.align(Alignment.End)
                                            ) {
                                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Order", tint = Color.Red.copy(alpha = 0.5f), modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }

                            Divider()

                            // Active Maintenance requests updating
                            Text("🛠️ طلبات وتذاكر الصيانة الواردة (${maintenanceRequests.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            if (maintenanceRequests.isEmpty()) {
                                Text("لا توجد طلبات صيانة بورشة الإصلاح حالياً.", color = Color.Gray, fontSize = 12.sp)
                            } else {
                                maintenanceRequests.forEach { maint ->
                                    var maintMenuExpanded by remember { mutableStateOf(false) }
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Box {
                                                    Button(
                                                        onClick = { maintMenuExpanded = true },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f), contentColor = MaterialTheme.colorScheme.secondary),
                                                        shape = RoundedCornerShape(4.dp)
                                                    ) {
                                                        Text("تحديث حالة: ${maint.status}", fontSize = 10.sp)
                                                    }

                                                    DropdownMenu(expanded = maintMenuExpanded, onDismissRequest = { maintMenuExpanded = false }) {
                                                        listOf("تم الاستلام", "تحت الفحص", "جاري الإصلاح", "بانتظار قطعه غيار", "تم الإصلاح", "جاهز للاستلام", "تم التسليم").forEach { s ->
                                                            DropdownMenuItem(
                                                                text = { Text(s, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
                                                                onClick = {
                                                                    viewModel.updateMaintenanceStatus(maint, s)
                                                                    maintMenuExpanded = false
                                                                }
                                                            )
                                                        }
                                                    }
                                                }

                                                Text("تذكرة: ${maint.requestNumber}", fontWeight = FontWeight.Bold)
                                            }

                                            Text("الجهاز: ${maint.deviceBrand} ${maint.deviceModel}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text("العميل: ${maint.clientName} (${maint.clientPhone})", fontSize = 11.sp)
                                            Text("العطل: ${maint.issueType} | درجة: ${maint.urgency}", fontSize = 11.sp, color = Color.Gray)
                                            Text("الوصف: ${maint.issueDescription}", fontSize = 11.sp, color = Color.DarkGray)

                                            IconButton(
                                                onClick = { viewModel.deleteMaintenanceRequest(maint) },
                                                modifier = Modifier.align(Alignment.End)
                                            ) {
                                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Request", tint = Color.Red.copy(alpha = 0.5f), modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        // Brand settings, Dynamic categories and Custom Coupon creations
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Coupon settings
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("🔑 إضافة كوبون خصم جديد", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                                    OutlinedTextField(
                                        value = newCouponCode,
                                        onValueChange = { newCouponCode = it },
                                        placeholder = { Text("مثال: WINTER25") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth().testTag("add_coupon_input")
                                    )

                                    OutlinedTextField(
                                        value = newCouponDiscount,
                                        onValueChange = { newCouponDiscount = it },
                                        placeholder = { Text("السعر المستقطع بنسبة مئوية (مثال: 15)") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    Button(
                                        onClick = {
                                            val percent = newCouponDiscount.toIntOrNull() ?: 15
                                            if (newCouponCode.isNotEmpty()) {
                                                viewModel.addCoupon(newCouponCode, percent)
                                                Toast.makeText(context, "تم حفظ الكوبون الجديد بنجاح!", Toast.LENGTH_SHORT).show()
                                                newCouponCode = ""
                                            }
                                        },
                                        modifier = Modifier.align(Alignment.End)
                                    ) {
                                        Text("إضافة الكوبون")
                                    }

                                    // List coupons
                                    Text("الكوبونات النشطة حالياً:", fontSize = 12.sp, color = Color.Gray)
                                    coupons.forEach { c ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(onClick = { viewModel.deleteCoupon(c) }) {
                                                Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color.Red)
                                            }
                                            Text("${c.code} (خصم %${c.discountPercent})", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            // Brand settings list and add custom brand
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("🏢 إضافة شركة مصنعة جديدة", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = newBrandName,
                                            onValueChange = { newBrandName = it },
                                            placeholder = { Text("مثال: OnePlus") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f).testTag("add_brand_input")
                                        )

                                        Button(
                                            onClick = {
                                                if (newBrandName.isNotEmpty()) {
                                                    viewModel.addBrand(newBrandName)
                                                    newBrandName = ""
                                                }
                                            }
                                        ) {
                                            Text("حفظ")
                                        }
                                    }

                                    Text("الأجهزة والشركات المتاحة:", fontSize = 12.sp, color = Color.Gray)
                                    brands.forEach { br ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(onClick = { viewModel.deleteBrand(br) }) {
                                                Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color.Red)
                                            }
                                            Text(br.name)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // New Product modal alert dialog
    if (showAddProdDialog) {
        AlertDialog(
            onDismissRequest = { showAddProdDialog = false },
            title = { Text("إقامة منتج جديد للمتجر", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(value = newProdName, onValueChange = { newProdName = it }, label = { Text("اسم المنتج") }, modifier = Modifier.fillMaxWidth())

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(value = newProdBrand, onValueChange = { newProdBrand = it }, label = { Text("الشركة") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = newProdCategory, onValueChange = { newProdCategory = it }, label = { Text("التوصيف بالفئة") }, modifier = Modifier.weight(1f))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(value = newProdPrice, onValueChange = { newProdPrice = it }, label = { Text("السعر") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = newProdOldPrice, onValueChange = { newProdOldPrice = it }, label = { Text("السعر القديم") }, modifier = Modifier.weight(1f))
                    }

                    OutlinedTextField(value = newProdCond, onValueChange = { newProdCond = it }, label = { Text("الحالة (جديد/مستعمل)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = newProdDesc, onValueChange = { newProdDesc = it }, label = { Text("الوصف العام") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = newProdFeat, onValueChange = { newProdFeat = it }, label = { Text("المميزات (تفصل بـ |)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = newProdDis, onValueChange = { newProdDis = it }, label = { Text("العيوب (تفصل بـ |)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = newProdSpecs, onValueChange = { newProdSpecs = it }, label = { Text("المواصفات الشاملة (مثال: الشاشة:6.1|المعالج:A2)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = newProdStock, onValueChange = { newProdStock = it }, label = { Text("كمية المنتج بالمخزون") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = newProdPrice.toDoubleOrNull() ?: 299.0
                        val op = newProdOldPrice.toDoubleOrNull() ?: p
                        val stock = newProdStock.toIntOrNull() ?: 10

                        if (newProdName.isNotEmpty()) {
                            viewModel.addProduct(
                                name = newProdName,
                                brand = newProdBrand,
                                category = newProdCategory,
                                price = p,
                                oldPrice = op,
                                condition = newProdCond,
                                description = newProdDesc,
                                features = if (newProdFeat.isEmpty()) "جودة تصنيع فائقة ممتازة" else newProdFeat,
                                disadvantages = if (newProdDis.isEmpty()) "سلك غير مرفق بالشاحن" else newProdDis,
                                specs = if (newProdSpecs.isEmpty()) "الضمان:سنة واحدة" else newProdSpecs,
                                stock = stock
                            )

                            showAddProdDialog = false
                            // Reset
                            newProdName = ""
                            newProdPrice = ""
                            newProdOldPrice = ""
                            newProdDesc = ""
                        }
                    }
                ) {
                    Text("إضافة المنتج للمخزن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddProdDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

fun activeAdminAdminTab(c: Int, t: Int) = c == t

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    bgColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.shadow(2.dp, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = textColor, modifier = Modifier.size(24.dp))
            Text(title, fontSize = 11.sp, color = textColor.copy(alpha = 0.8f))
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = textColor)
        }
    }
}

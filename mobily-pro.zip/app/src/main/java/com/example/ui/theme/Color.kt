package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Mobily Pro Frosted Glass Theme Colors
val Purple80 = Color(0xFFD4C9FF)
val PurpleGrey80 = Color(0xFFCBC4DF)
val Blue80 = Color(0xFFF5BFCF)

val PurplePrimary = Color(0xFF5E4BF5) // Modern Vibrant Electric Indigo
val PurpleDark = Color(0xFF1E1B4B) // Deep Noble Indigo Headings (slate-like)
val BlueRoyal = Color(0xFF2563EB) // Royal Blue / Accent
val PurpleGrey40 = Color(0xFF5C5770)
val BlueAccent = Color(0xFF4F46E5) // Accent Indigo

// Outline and translucent glass colors
val OutlineLight = Color(0xFFDCD6FF)
val FrostedBgLight = Color(0xFFF4F3FF) // Soft luxurious lilac/lavender background from screenshots
val FrostedBgDark = Color(0xFF0D0B14) // Rich dark space-purple backdrop

// Semi-transparent frosted glass fills
val GlassFillLight = Color(0x73FFFFFF) // 45% white for soft glass look
val GlassFillDark = Color(0x2EFFFFFF)  // Dark mode white translucency
val GlassBorderLight = Color(0x66D0C5FF) // Shimmering light borders
val GlassBorderDark = Color(0x26FFFFFF)

// Solid fallback surfaces
val GrayBgLight = Color(0xFFF4F3FF)
val GrayBgDark = Color(0xFF0D0B14)
val CardBgLight = Color(0xFFFFFFFF)
val CardBgDark = Color(0xFF171520)


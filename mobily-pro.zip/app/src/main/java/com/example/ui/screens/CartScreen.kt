package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Product
import com.example.ui.MainViewModel
import com.example.ui.theme.frostedGlass

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    viewModel: MainViewModel,
    onNavigateToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val products by viewModel.products.collectAsState()
    val cart by viewModel.cart.collectAsState()
    val appliedCoupon by viewModel.appliedCoupon.collectAsState()
    val couponError by viewModel.couponError.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()

    // Form Checkout state
    var clientName by remember { mutableStateOf(userProfile.name) }
    var clientPhone by remember { mutableStateOf(userProfile.phone) }
    var clientProvince by remember { mutableStateOf(userProfile.province) }
    var clientCity by remember { mutableStateOf(userProfile.city) }
    var clientAddress by remember { mutableStateOf(userProfile.address) }

    var couponInput by remember { mutableStateOf("") }
    var isCheckingOut by remember { mutableStateOf(false) }

    // Success dialog state
    var generatedOrderNumber by remember { mutableStateOf<String?>(null) }

    // Map cart items with their product details
    val cartItemsWithDetails = remember(cart, products) {
        cart.mapNotNull { (pid, qty) ->
            val p = products.find { it.id == pid }
            if (p != null) p to qty else null
        }
    }

    // Mathematical calculations
    val itemsSubtotal = remember(cartItemsWithDetails) {
        cartItemsWithDetails.sumOf { (prod, qty) -> prod.price * qty }
    }

    val couponDiscountAmount = remember(appliedCoupon, itemsSubtotal) {
        if (appliedCoupon != null) {
            itemsSubtotal * (appliedCoupon!!.discountPercent / 100.0)
        } else 0.0
    }

    val shippingFee = remember(clientProvince) {
        viewModel.getShippingCost(clientProvince)
    }

    val finalGrandTotal = remember(itemsSubtotal, couponDiscountAmount, shippingFee) {
        (itemsSubtotal - couponDiscountAmount + shippingFee).coerceAtLeast(0.0)
    }

    // Provinces dropdown values
    val saudiProvinces = listOf(
        "الرياض", "مكة المكرمة", "جدة", "الشرقية", "الدمام",
        "المدينة المنورة", "عسير", "تبوك", "القصيم", "جازان"
    )

    var provinceMenuExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("سلة المشتريات والدفع", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent
                ),
                actions = {
                    if (cart.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearCart() }) {
                            Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "Clear", tint = Color.Red)
                        }
                    }
                }
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        if (cart.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = "Empty",
                        tint = Color.LightGray,
                        modifier = Modifier.size(90.dp)
                    )
                    Text("سلتك خالية حالياً! تسوق واكتشف أحدث العروض.", color = Color.Gray, fontSize = 14.sp)
                    Button(onClick = onNavigateToHome) {
                        Text("اذهب للمتجر")
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Cart Items list
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text(
                            text = "العناصر المضافة (${cartItemsWithDetails.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }

                    items(cartItemsWithDetails) { (prod, qty) ->
                        CartItemRow(
                            product = prod,
                            quantity = qty,
                            onIncrement = { viewModel.addToCart(prod.id) },
                            onDecrement = { viewModel.subtractFromCart(prod.id) },
                            onRemove = { viewModel.removeFromCart(prod.id) }
                        )
                    }

                    item {
                        Divider(modifier = Modifier.padding(vertical = 12.dp))
                    }

                    // Promo Coupons card
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .frostedGlass(RoundedCornerShape(16.dp)),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("هل لديك كوبون خصم؟", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = couponInput,
                                        onValueChange = { couponInput = it },
                                        placeholder = { Text("مثال: MOBILY10", fontSize = 12.sp) },
                                        singleLine = true,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(52.dp)
                                            .testTag("coupon_input")
                                    )

                                    Button(
                                        onClick = {
                                            if (couponInput.isNotEmpty()) {
                                                viewModel.applyCoupon(couponInput)
                                            }
                                        },
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("تطبيق")
                                    }
                                }

                                if (appliedCoupon != null) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFFE8F5E9), RoundedCornerShape(4.dp))
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(onClick = { viewModel.removeCoupon() }) {
                                            Icon(imageVector = Icons.Default.Close, contentDescription = "Remove", tint = Color.Red, modifier = Modifier.size(16.dp))
                                        }
                                        Text("تم تطبيق كوبون ${appliedCoupon!!.code} بخصم %${appliedCoupon!!.discountPercent}", color = Color(0xFF2E7D32), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                if (couponError.isNotEmpty()) {
                                    Text(couponError, color = Color.Red, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right)
                                }
                            }
                        }
                    }

                    // Total billing breakdown
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .frostedGlass(RoundedCornerShape(16.dp)),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("ملخص الفاتورة", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${itemsSubtotal} ر.س", fontWeight = FontWeight.Medium)
                                    Text("المجموع الفرعي:", color = Color.Gray)
                                }

                                if (appliedCoupon != null) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("-${couponDiscountAmount} ر.س", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                        Text("خصم الكوبون (%${appliedCoupon!!.discountPercent}):", color = Color.Gray)
                                    }
                                }

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${shippingFee} ر.س", fontWeight = FontWeight.Medium)
                                    Text("تكلفة الشحن والتوصيل:", color = Color.Gray)
                                }

                                Divider()

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${finalGrandTotal} ر.س", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Text("المجموع الإجمالي النهائي:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Delivery checkout parameters
                    item {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "بيانات التوصيل والشحن",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .frostedGlass(RoundedCornerShape(20.dp)),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedTextField(
                                    value = clientName,
                                    onValueChange = { clientName = it },
                                    label = { Text("الاسم الكريم المستلم") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("checkout_name")
                                )

                                OutlinedTextField(
                                    value = clientPhone,
                                    onValueChange = { clientPhone = it },
                                    label = { Text("رقم جوال المستلم") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("checkout_phone")
                                )

                                // Governorate Dropdown
                                Box {
                                    OutlinedTextField(
                                        value = clientProvince,
                                        onValueChange = { },
                                        readOnly = true,
                                        label = { Text("المحافظة") },
                                        trailingIcon = {
                                            IconButton(onClick = { provinceMenuExpanded = true }) {
                                                Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().clickable { provinceMenuExpanded = true }
                                    )

                                    DropdownMenu(
                                        expanded = provinceMenuExpanded,
                                        onDismissRequest = { provinceMenuExpanded = false }
                                    ) {
                                        saudiProvinces.forEach { prov ->
                                            DropdownMenuItem(
                                                text = { Text(prov, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
                                                onClick = {
                                                    clientProvince = prov
                                                    provinceMenuExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = clientCity,
                                    onValueChange = { clientCity = it },
                                    label = { Text("المدينة / الحي") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = clientAddress,
                                    onValueChange = { clientAddress = it },
                                    label = { Text("العنوان بالتفصيل (الشارع والمنزل)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Text(
                                            text = "طريقة الدفع الحالية المتاحة: الدفع عند الاستلام (مجاناً)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(32.dp))
                    }
                }

                // Fixed bottom button containing checkout triggers
                Surface(
                    tonalElevation = 8.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    Box(modifier = Modifier.padding(16.dp)) {
                        Button(
                            onClick = {
                                if (clientName.isEmpty() || clientPhone.isEmpty() || clientCity.isEmpty() || clientAddress.isEmpty()) {
                                    Toast.makeText(context, "الرجاء تعبئة الاسم والجوال والمدينة والعنوان للتوصيل بنجاح", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.placeOrder(
                                        name = clientName,
                                        phone = clientPhone,
                                        province = clientProvince,
                                        city = clientCity,
                                        address = clientAddress
                                    ) { ordNum ->
                                        generatedOrderNumber = ordNum
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("confirm_order_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("تأكيد وشراء الطلب بقيمة ${finalGrandTotal} ر.س 🛒", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }

    // Success Dialogue
    if (generatedOrderNumber != null) {
        AlertDialog(
            onDismissRequest = {
                generatedOrderNumber = null
                onNavigateToHome()
            },
            icon = { Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF43A047), modifier = Modifier.size(54.dp)) },
            title = { Text("تم تأكيد طلبك بنجاح! 🎉", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "رقم تتبع طلبك: ${generatedOrderNumber!!}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "شكراً لثقتك بموبايلي برو. يقوم فريق خدمة العملاء بمراجعة وتأكيد طلبك وتجهيزه للشحن حالياً وسنتصل بك قريباً لتأكيد موعد التوصيل.",
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        color = Color.DarkGray,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        generatedOrderNumber = null
                        onNavigateToHome()
                    }
                ) {
                    Text("العودة للمتجر الرئيسي")
                }
            }
        )
    }
}

@Composable
fun CartItemRow(
    product: Product,
    quantity: Int,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Remove Button
            IconButton(onClick = onRemove) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.LightGray)
            }

            // Price & Quantity controls
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("${product.price * quantity} ر.س", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(
                        onClick = onIncrement,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .size(24.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    }

                    Text("$quantity", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                    IconButton(
                        onClick = onDecrement,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .size(24.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Column of titles
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.End
            ) {
                Text(product.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, textAlign = TextAlign.Right)
                Text(product.brand, fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Right)
                Text("سعر مفرد: ${product.price} ر.س", fontSize = 10.sp, color = Color.LightGray, textAlign = TextAlign.Right)
            }

            // Image Thumbnail
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(Color.LightGray.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                val icon = if (product.category == "سماعات") Icons.Default.Headphones
                else if (product.category == "ساعات ذكية") Icons.Default.Watch
                else if (product.category == "شواحن" || product.category == "باور بانك") Icons.Default.Bolt
                else if (product.category == "قطع غيار") Icons.Default.Build
                else Icons.Default.Smartphone

                Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), modifier = Modifier.size(24.dp))
            }
        }
    }
}

package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Product
import com.example.data.UserRating
import com.example.ui.MainViewModel
import com.example.ui.theme.frostedGlass

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailsScreen(
    viewModel: MainViewModel,
    productId: Int,
    onNavigateBack: () -> Unit,
    onNavigateToProduct: (Int) -> Unit,
    onNavigateToCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val products by viewModel.products.collectAsState()
    val wishlist by viewModel.wishlist.collectAsState()
    val ratings by viewModel.ratings.collectAsState()

    val product = remember(products, productId) {
        products.find { it.id == productId }
    }

    if (product == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("المنتج غير موجود.")
        }
        return
    }

    // Filter reviews specific to this product
    val productReviews = remember(ratings, productId) {
        ratings.filter { it.productId == productId }
    }

    var selectedColor by remember { mutableStateOf("تيتانيوم طبيعي") }
    var selectedCapacity by remember { mutableStateOf("256 جيجابايت") }
    var selectedRam by remember { mutableStateOf("8 جيجابايت") }

    // Image Zoom simulation state
    var isZoomed by remember { mutableStateOf(false) }

    // Writing review states
    var showReviewDialog by remember { mutableStateOf(false) }
    var reviewName by remember { mutableStateOf("") }
    var reviewRating by remember { mutableStateOf(5) }
    var reviewComment by remember { mutableStateOf("") }

    // Suggested products
    val suggestedProducts = remember(products, product) {
        products.filter { it.category == product.category && it.id != product.id }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(product.name, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleWishlist(product.id) }) {
                        Icon(
                            imageVector = if (wishlist.contains(product.id)) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Wishlist Toggle",
                            tint = if (wishlist.contains(product.id)) Color.Red else Color.Gray
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = Color.Transparent,
        bottomBar = {
            // Fixed bottom navigation action bar
            Surface(
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Call Button
                    IconButton(
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:0512345678"))
                            context.startActivity(intent)
                        },
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape)
                            .size(46.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Phone, contentDescription = "Call Store", tint = MaterialTheme.colorScheme.primary)
                    }

                    // Whatsapp Button
                    IconButton(
                        onClick = {
                            val msg = "مرحباً موبايلي برو، أريد الاستفسار عن منتج: ${product.name} بسعر ${product.price} ر.س"
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/966512345678?text=${Uri.encode(msg)}"))
                            try {
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "لم يتم العثور على تطبيق واتساب", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .background(Color(0xFF25D366).copy(alpha = 0.1f), CircleShape)
                            .size(46.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Chat, contentDescription = "Whatsapp Store", tint = Color(0xFF25D366))
                    }

                    // Add To Cart
                    Button(
                        onClick = {
                            viewModel.addToCart(product.id)
                            Toast.makeText(context, "تمت الإضافة للسلة بنجاح!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("add_to_cart_details_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إضافة للسلة", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    // Buy Now Button
                    Button(
                        onClick = {
                            viewModel.addToCart(product.id)
                            onNavigateToCart()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Text("شراء الآن", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // Interactive visual gallery with zoom
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clickable { isZoomed = !isZoomed }
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.04f),
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                val scale = if (isZoomed) 1.4f else 1.0f

                val displayIcon = if (product.category == "سماعات") Icons.Default.Headphones
                else if (product.category == "ساعات ذكية") Icons.Default.Watch
                else if (product.category == "شواحن" || product.category == "باور بانك") Icons.Default.Bolt
                else if (product.category == "قطع غيار") Icons.Default.Build
                else Icons.Default.Smartphone

                Icon(
                    imageVector = displayIcon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .size((120 * scale).dp)
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isZoomed) "انقر للتصغير 🔍" else "انقر للتكبير 🔍",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Condition Tag on top details corner
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Badge(containerColor = if (product.condition == "جديد") Color(0xFF43A047) else Color(0xFF1E88E5)) {
                        Text(product.condition, color = Color.White, modifier = Modifier.padding(4.dp), fontSize = 11.sp)
                    }

                    if (product.conditionGrade != null) {
                        Badge(containerColor = MaterialTheme.colorScheme.secondary) {
                            Text("حالة: ${product.conditionGrade}", color = Color.White, modifier = Modifier.padding(4.dp), fontSize = 11.sp)
                        }
                    }
                }
            }

            // Core information: Title, rating, pricing, stock
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${product.price} ر.س",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (product.oldPrice > product.price) {
                            Text(
                                text = "${product.oldPrice} ر.س",
                                fontSize = 14.sp,
                                textDecoration = TextDecoration.LineThrough,
                                color = Color.LightGray
                            )
                        }
                    }

                    // Stock availability
                    val stockText = if (product.stockQuantity > 3) "متوفر بالمخزون (${product.stockQuantity})"
                    else if (product.stockQuantity > 0) "كمية محدودة جداً بقيت (${product.stockQuantity})!"
                    else "نفذ من المخزون ❌"

                    val stockColor = if (product.stockQuantity > 3) Color(0xFF43A047)
                    else if (product.stockQuantity > 0) Color(0xFFFF8F00)
                    else Color(0xFFE53935)

                    Text(
                        text = stockText,
                        color = stockColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                // If used, battery state & report parameters
                if (product.condition == "مستعمل") {
                    UsedProductDetailsSpecs(product)
                }

                Divider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)

                // Selectors (Color, storage, etc.)
                Text("تخصيص الخيارات", fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(bottom = 6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("اللون", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.LightGray.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .clickable { }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(selectedColor, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("السعة التخزينية", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.LightGray.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .clickable { }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(selectedCapacity, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)

                // Description
                Text("الوصف الفني للمنتج", fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(bottom = 6.dp))
                Text(
                    text = product.description,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    color = Color.DarkGray,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )

                Divider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)

                // Pros & Cons (المميزات والعيوب)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("🟢 المميزات", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2E7D32))
                        Spacer(modifier = Modifier.height(6.dp))
                        product.features.split("|").forEach { feat ->
                            Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
                                Text("•", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 4.dp))
                                Text(feat, fontSize = 11.sp, color = Color.DarkGray, lineHeight = 14.sp)
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("🔴 العيوب", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFC62828))
                        Spacer(modifier = Modifier.height(6.dp))
                        product.disadvantages.split("|").forEach { dis ->
                            Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
                                Text("•", color = Color(0xFFC62828), fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 4.dp))
                                Text(dis, fontSize = 11.sp, color = Color.DarkGray, lineHeight = 14.sp)
                            }
                        }
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)

                // Specifications
                Text("المواصفات الشاملة", fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
                product.specs.split("|").forEach { spec ->
                    val parts = spec.split(":")
                    if (parts.size == 2) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(parts[1], fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                            Text(parts[0], fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)

                // Constant store advantages (الضمان والاستبدال)
                StorePolicyBenefits()

                Divider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)

                // Customer Ratings section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تقييمات ومراجعات العملاء", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Button(
                        onClick = { showReviewDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), contentColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("قيم هذا المنتج", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (productReviews.isEmpty()) {
                    Text("لا توجد مراجعات لهذا المنتج بعد. كن أول من يضيف تقييماً!", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        productReviews.forEach { review ->
                            RatingItemRow(review)
                        }
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)

                // Similar recommended products
                if (suggestedProducts.isNotEmpty()) {
                    Text("منتجات مشابهة قد تعجبك", fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(suggestedProducts) { sug ->
                            ProductCardCompact(
                                product = sug,
                                isFavorite = wishlist.contains(sug.id),
                                onFavToggle = { viewModel.toggleWishlist(sug.id) },
                                onClick = { onNavigateToProduct(sug.id) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(100.dp))
        }
    }

    // Interactive Review dialogue
    if (showReviewDialog) {
        AlertDialog(
            onDismissRequest = { showReviewDialog = false },
            title = { Text("أضف تقييمك للمنتج", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = reviewName,
                        onValueChange = { reviewName = it },
                        label = { Text("الاسم الكريم") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Column {
                        Text("التقييم بالنجوم")
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            (1..5).forEach { stars ->
                                IconButton(onClick = { reviewRating = stars }) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = if (stars <= reviewRating) Color(0xFFFFB300) else Color.LightGray
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = reviewComment,
                        onValueChange = { reviewComment = it },
                        label = { Text("رأيك بالمنتج") },
                        placeholder = { Text("اكتب ملاحظاتك، مراجعتك الفنية...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reviewName.isNotEmpty()) {
                            viewModel.addProductReview(product.id, reviewName, reviewRating, reviewComment)
                            showReviewDialog = false
                            reviewName = ""
                            reviewComment = ""
                            Toast.makeText(context, "شكراً لإضافة مراجعتك القيمة!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("إرسال التقييم")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReviewDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun UsedProductDetailsSpecs(product: Product) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        border = BorderStroke(1.dp, Color(0xFFFFB74D))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🗂️ تقرير حالة وفحص الهاتف المستعمل:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFE65100))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("🔋 صحة البطارية: %${product.batteryHealth ?: 100}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("📅 مدة الاستخدام: ${product.usageDuration ?: "غير محدد"}", fontSize = 12.sp)
            }

            Text("📺 حالة الشاشة: ${product.screenStatus ?: "سليمة"}", fontSize = 12.sp, color = Color.DarkGray)
            Text("🔧 حالة الهيكل والاطار: ${product.bodyStatus ?: "ممتازة"}", fontSize = 12.sp, color = Color.DarkGray)

            Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(top = 4.dp)) {
                Icon(imageVector = Icons.Default.FactCheck, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = product.testReport ?: "تم اجتياز الفحص البرمجي للأزرار، الكاميرا والواي فاي.",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
fun StorePolicyBenefits() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
            Column {
                Text("الضمان المعتمد", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("جميع منتجاتنا مشمولة بضمان الوكيل الرسمي أو ضمان موبايلي برو الفضي لمدة عام.", fontSize = 10.sp, color = Color.Gray)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.PublishedWithChanges, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(24.dp))
            Column {
                Text("سياسة استبدال مرنة", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("يمكنك استبدال أو استرجاع المنتجات بسهولة تامة خلال ١٤ يوماً تماشياً مع أنظمة وزارة التجارة.", fontSize = 10.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun RatingItemRow(review: UserRating) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier
            .fillMaxWidth()
            .frostedGlass(RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    (1..5).forEach { s ->
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (s <= review.rating) Color(0xFFFFB300) else Color.LightGray,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }

                Text(review.userName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            if (review.comment.isNotEmpty()) {
                Text(
                    text = review.comment,
                    fontSize = 11.sp,
                    color = Color.DarkGray,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Global frosted glass extension modifier
@Composable
fun Modifier.frostedGlass(
  shape: Shape = RoundedCornerShape(24.dp),
  borderWidth: Dp = 1.dp
): Modifier {
  val isDark = isSystemInDarkTheme()
  val bgColor = if (isDark) GlassFillDark else GlassFillLight
  val borderColor = if (isDark) GlassBorderDark else GlassBorderLight

  return this
    .background(bgColor, shape)
    .border(borderWidth, borderColor, shape)
}

// Global premium soft gradient background extension modifier
@Composable
fun Modifier.premiumBackground(): Modifier {
  val isDark = isSystemInDarkTheme()
  val gradientColors = if (isDark) {
    listOf(Color(0xFF141124), Color(0xFF0A0910))
  } else {
    listOf(Color(0xFFECE9FF), Color(0xFFF6F5FC))
  }
  return this.background(
    brush = androidx.compose.ui.graphics.Brush.verticalGradient(gradientColors)
  )
}

private val DarkColorScheme =
  darkColorScheme(
    primary = Purple80,
    secondary = PurpleGrey80,
    tertiary = Blue80,
    background = GrayBgDark,
    surface = CardBgDark,
    onPrimary = Color(0xFF121212),
    onSecondary = Color(0xFF121212),
    onBackground = Color(0xFFE6E1E5),
    onSurface = Color(0xFFE6E1E5),
    outline = GlassBorderDark
  )

private val LightColorScheme =
  lightColorScheme(
    primary = PurplePrimary,
    secondary = BlueRoyal,
    tertiary = BlueAccent,
    background = GrayBgLight,
    surface = CardBgLight,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color(0xFF1C1B1F),
    onSurface = Color(0xFF1C1B1F),
    outline = OutlineLight
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disabling dynamicColor by default to guarantee our custom exquisite brand design
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

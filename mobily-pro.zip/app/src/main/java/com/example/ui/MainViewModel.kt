package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = Repository(db.dbDao())

    // --- State Flows ---
    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val brands: StateFlow<List<Brand>> = repository.allBrands
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val maintenanceRequests: StateFlow<List<MaintenanceRequest>> = repository.allMaintenanceRequests
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val coupons: StateFlow<List<Coupon>> = repository.allCoupons
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val ratings: StateFlow<List<UserRating>> = repository.allRatings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- UI Local States ---
    private val _cart = MutableStateFlow<Map<Int, Int>>(emptyMap()) // productId -> quantity
    val cart: StateFlow<Map<Int, Int>> = _cart.asStateFlow()

    private val _wishlist = MutableStateFlow<Set<Int>>(emptySet()) // set of productIds
    val wishlist: StateFlow<Set<Int>> = _wishlist.asStateFlow()

    // Active User simulation
    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    // Coupon logic
    private val _appliedCoupon = MutableStateFlow<Coupon?>(null)
    val appliedCoupon: StateFlow<Coupon?> = _appliedCoupon.asStateFlow()

    val couponError = MutableStateFlow("")

    // Search and Filter states
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow<String?>("الكل")
    val selectedBrand = MutableStateFlow<String?>(null)
    val priceRange = MutableStateFlow(0f..6000f)
    val selectedCondition = MutableStateFlow<String?>("الكل") // "الكل", "جديد", "مستعمل"

    // Maintenance tracking states
    val trackingPhone = MutableStateFlow("")
    val trackingNumber = MutableStateFlow("")
    private val _trackedRequest = MutableStateFlow<MaintenanceRequest?>(null)
    val trackedRequest: StateFlow<MaintenanceRequest?> = _trackedRequest.asStateFlow()
    val trackingSearchCompleted = MutableStateFlow(false)

    // Admin login trigger
    val isAdminLoggedIn = MutableStateFlow(false)

    init {
        // Init profile with some mock data if they open
        _userProfile.value = UserProfile(
            name = "محمد أحمد",
            phone = "0512345678",
            email = "demo@mobilypro.com",
            province = "الرياض",
            city = "الرياض",
            address = "شارع العليا العام، حي الورود",
            isLoggedIn = true
        )
    }

    // --- Cart Actions ---
    fun addToCart(productId: Int) {
        viewModelScope.launch {
            val currentMap = _cart.value.toMutableMap()
            val prod = products.value.find { it.id == productId }
            val stock = prod?.stockQuantity ?: 10
            val currentVal = currentMap[productId] ?: 0
            if (currentVal < stock) {
                currentMap[productId] = currentVal + 1
                _cart.value = currentMap
            }
        }
    }

    fun subtractFromCart(productId: Int) {
        val currentMap = _cart.value.toMutableMap()
        val currentVal = currentMap[productId] ?: 0
        if (currentVal > 1) {
            currentMap[productId] = currentVal - 1
        } else {
            currentMap.remove(productId)
        }
        _cart.value = currentMap
    }

    fun removeFromCart(productId: Int) {
        val currentMap = _cart.value.toMutableMap()
        currentMap.remove(productId)
        _cart.value = currentMap
    }

    fun applyCoupon(code: String) {
        viewModelScope.launch {
            val coupon = repository.getCouponByCode(code.trim().uppercase())
            if (coupon != null) {
                _appliedCoupon.value = coupon
                couponError.value = ""
            } else {
                _appliedCoupon.value = null
                couponError.value = "كوبون غير صحيح أو منتهي الصلاحية"
            }
        }
    }

    fun removeCoupon() {
        _appliedCoupon.value = null
        couponError.value = ""
    }

    fun clearCart() {
        _cart.value = emptyMap()
        _appliedCoupon.value = null
    }

    // Shipping cost formula based on province
    fun getShippingCost(province: String): Double {
        return when (province.trim()) {
            "الرياض" -> 15.0
            "مكة المكرمة", "جدة" -> 25.0
            "الشرقية", "الدمام", "الخبر" -> 20.0
            "المدينة المنورة" -> 25.0
            "عسير", "أبها" -> 30.0
            "تبوك" -> 30.0
            else -> 35.0
        }
    }

    // --- Wishlist Actions ---
    fun toggleWishlist(productId: Int) {
        val currentSet = _wishlist.value.toMutableSet()
        if (currentSet.contains(productId)) {
            currentSet.remove(productId)
        } else {
            currentSet.add(productId)
        }
        _wishlist.value = currentSet
    }

    // --- User Maintenance Submission ---
    fun submitMaintenanceRequest(
        name: String,
        phone: String,
        brand: String,
        model: String,
        issueType: String,
        description: String,
        urgency: String,
        onSuccess: (String) -> Unit
    ) {
        viewModelScope.launch {
            val trackingNum = "MP-${Random.nextInt(100000, 999999)}"
            val req = MaintenanceRequest(
                requestNumber = trackingNum,
                clientName = name,
                clientPhone = phone,
                deviceBrand = brand,
                deviceModel = model,
                issueDescription = description,
                issueType = issueType,
                urgency = urgency,
                status = "تم الاستلام"
            )
            repository.insertMaintenance(req)
            onSuccess(trackingNum)
        }
    }

    // --- Track Maintenance ---
    fun trackMaintenance(phone: String, reqNumber: String) {
        viewModelScope.launch {
            val req = repository.getMaintenanceByTracking(reqNumber.trim(), phone.trim())
            _trackedRequest.value = req
            trackingSearchCompleted.value = true
        }
    }

    fun clearTrackingSearch() {
        _trackedRequest.value = null
        trackingSearchCompleted.value = false
    }

    // --- Submit Order ---
    fun placeOrder(
        name: String,
        phone: String,
        province: String,
        city: String,
        address: String,
        onSuccess: (String) -> Unit
    ) {
        viewModelScope.launch {
            val orderNum = "OD-${Random.nextInt(100000, 999999)}"
            val currentCart = _cart.value

            // Build item description string
            val itemsDescription = currentCart.mapNotNull { (pid, qty) ->
                val prod = products.value.find { it.id == pid }
                prod?.let { "${it.name} (${qty}x)" }
            }.joinToString(", ")

            // Calculate amounts
            var itemsTotal = 0.0
            currentCart.forEach { (pid, qty) ->
                val prod = products.value.find { it.id == pid }
                if (prod != null) {
                    itemsTotal += prod.price * qty
                }
            }

            val discount = _appliedCoupon.value?.let { itemsTotal * (it.discountPercent / 100.0) } ?: 0.0
            val shipping = getShippingCost(province)
            val grandTotal = itemsTotal - discount + shipping

            val newOrder = Order(
                orderNumber = orderNum,
                clientName = name,
                clientPhone = phone,
                clientProvince = province,
                clientCity = city,
                clientAddress = address,
                shippingCost = shipping,
                totalAmount = grandTotal,
                status = "قيد المراجعة",
                itemsJson = itemsDescription,
                couponCode = _appliedCoupon.value?.code
            )

            repository.insertOrder(newOrder)

            // Reduce stock
            currentCart.forEach { (pid, qty) ->
                val prod = products.value.find { it.id == pid }
                if (prod != null) {
                    val updatedProd = prod.copy(
                        stockQuantity = (prod.stockQuantity - qty).coerceAtLeast(0)
                    )
                    repository.updateProduct(updatedProd)
                }
            }

            // Save user details
            _userProfile.value = _userProfile.value.copy(
                name = name,
                phone = phone,
                province = province,
                city = city,
                address = address
            )

            clearCart()
            onSuccess(orderNum)
        }
    }

    // --- Admin Dashboard Control Actions ---

    fun addProduct(
        name: String,
        brand: String,
        category: String,
        price: Double,
        oldPrice: Double,
        condition: String,
        description: String,
        features: String,
        disadvantages: String,
        specs: String,
        stock: Int,
        batteryHealth: Int? = null,
        screenStatus: String? = null,
        bodyStatus: String? = null,
        usageDuration: String? = null,
        testReport: String? = null,
        conditionGrade: String? = null,
        isPopular: Boolean = false,
        isLightningDeal: Boolean = false
    ) {
        viewModelScope.launch {
            val discPercent = if (oldPrice > price) {
                (((oldPrice - price) / oldPrice) * 100).toInt()
            } else 0

            val product = Product(
                name = name,
                brand = brand,
                category = category,
                price = price,
                oldPrice = oldPrice,
                discountPercent = discPercent,
                condition = condition,
                imageUrls = if (category == "هواتف جديدة" || category == "هواتف مستعملة") {
                    if (brand.lowercase().contains("apple")) "iphone_15_pro_max" else "samsung_s24_ultra"
                } else if (category == "سماعات") "airpods_pro_2" else "redmi_watch_4",
                description = description,
                features = features,
                disadvantages = disadvantages,
                specs = specs,
                rating = 5.0f,
                reviewCount = 0,
                batteryHealth = batteryHealth,
                screenStatus = screenStatus,
                bodyStatus = bodyStatus,
                usageDuration = usageDuration,
                testReport = testReport,
                conditionGrade = conditionGrade,
                stockQuantity = stock,
                isPopular = isPopular,
                isLightningDeal = isLightningDeal,
                lightningEndTime = if (isLightningDeal) System.currentTimeMillis() + 86400000 else null
            )
            repository.insertProduct(product)
        }
    }

    fun editProduct(product: Product) {
        viewModelScope.launch {
            repository.updateProduct(product)
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }

    fun updateMaintenanceStatus(request: MaintenanceRequest, newStatus: String) {
        viewModelScope.launch {
            repository.updateMaintenance(request.copy(status = newStatus))
        }
    }

    fun deleteMaintenanceRequest(request: MaintenanceRequest) {
        viewModelScope.launch {
            repository.deleteMaintenance(request)
        }
    }

    fun updateOrderStatus(order: Order, newStatus: String) {
        viewModelScope.launch {
            repository.updateOrder(order.copy(status = newStatus))
        }
    }

    fun deleteOrder(order: Order) {
        viewModelScope.launch {
            repository.deleteOrder(order)
        }
    }

    fun addBrand(name: String) {
        viewModelScope.launch {
            repository.insertBrand(Brand(name = name))
        }
    }

    fun deleteBrand(brand: Brand) {
        viewModelScope.launch {
            repository.deleteBrand(brand)
        }
    }

    fun addCategory(name: String, iconName: String) {
        viewModelScope.launch {
            repository.insertCategory(Category(name = name, iconName = iconName))
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            repository.deleteCategory(category)
        }
    }

    fun addCoupon(code: String, percent: Int) {
        viewModelScope.launch {
            repository.insertCoupon(
                Coupon(
                    code = code.trim().uppercase(),
                    discountPercent = percent,
                    expiryDate = System.currentTimeMillis() + 86400000 * 30 // 30 days
                )
            )
        }
    }

    fun deleteCoupon(coupon: Coupon) {
        viewModelScope.launch {
            repository.deleteCoupon(coupon)
        }
    }

    fun addProductReview(productId: Int, userName: String, ratingVal: Int, commentVal: String) {
        viewModelScope.launch {
            val rating = UserRating(
                productId = productId,
                userName = userName,
                rating = ratingVal,
                comment = commentVal
            )
            repository.insertRating(rating)

            // Auto update product average rating
            val allProds = products.value
            val prod = allProds.find { it.id == productId }
            if (prod != null) {
                val newReviewCount = prod.reviewCount + 1
                val newRating = ((prod.rating * prod.reviewCount) + ratingVal) / newReviewCount
                repository.updateProduct(
                    prod.copy(
                        reviewCount = newReviewCount,
                        rating = newRating
                    )
                )
            }
        }
    }

    fun updateUserProfile(profile: UserProfile) {
        _userProfile.value = profile
    }
}

data class UserProfile(
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val province: String = "الرياض",
    val city: String = "",
    val address: String = "",
    val isLoggedIn: Boolean = false
)

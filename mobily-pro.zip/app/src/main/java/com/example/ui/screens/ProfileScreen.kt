package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Order
import com.example.data.Product
import com.example.ui.MainViewModel
import com.example.ui.UserProfile
import com.example.ui.theme.frostedGlass

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: MainViewModel,
    onNavigateToProduct: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val userProfile by viewModel.userProfile.collectAsState()
    val wishlist by viewModel.wishlist.collectAsState()
    val products by viewModel.products.collectAsState()
    val orders by viewModel.orders.collectAsState()

    var activeProfileSubTab by remember { mutableStateOf(0) } // 0: الطلبات السابقة, 1: المفضلة, 2: البيانات الشخصية

    // Edit profile states
    var editName by remember { mutableStateOf(userProfile.name) }
    var editPhone by remember { mutableStateOf(userProfile.phone) }
    var editEmail by remember { mutableStateOf(userProfile.email) }
    var editAddress by remember { mutableStateOf(userProfile.address) }

    // Map wishlist products
    val wishlistedProducts = remember(wishlist, products) {
        products.filter { wishlist.contains(it.id) }
    }

    // Filter orders corresponding to this client's phone for simplicity of localization
    val clientOrders = remember(orders, userProfile.phone) {
        orders.filter { it.clientPhone.trim() == userProfile.phone.trim() }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("حسابي الشخصي", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Elegant user banner card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.secondary
                            )
                        )
                    )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Profile picture avatar simulation icon
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .background(Color.White.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(34.dp))
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(userProfile.name.ifEmpty { "عميل زائر مسجل" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(userProfile.phone.ifEmpty { "لا يوجد جوال مسجل" }, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text(userProfile.email.ifEmpty { "No Email" }, color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                    }
                }
            }

            // Tab toggles
            TabRow(selectedTabIndex = activeProfileSubTab) {
                Tab(
                    selected = activeProfileSubTab == 0,
                    onClick = { activeProfileSubTab = 0 },
                    text = { Text("طلبـاتي", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
                Tab(
                    selected = activeProfileSubTab == 1,
                    onClick = { activeProfileSubTab = 1 },
                    text = { Text("المفضلة (${wishlistedProducts.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
                Tab(
                    selected = activeProfileSubTab == 2,
                    onClick = { activeProfileSubTab = 2 },
                    text = { Text("بياناتي", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
            }

            AnimatedContent(
                targetState = activeProfileSubTab,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                label = "Profile page animation"
            ) { subIndex ->
                when (subIndex) {
                    0 -> {
                        // User Orders History list
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (clientOrders.isEmpty()) {
                                item {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(54.dp))
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text("لم تقم بإرسال أي طلبات شراء للمتجر بعد.", color = Color.Gray, fontSize = 13.sp)
                                        }
                                    }
                                }
                            } else {
                                items(clientOrders) { order ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .frostedGlass(RoundedCornerShape(16.dp)),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Badge(containerColor = getStatusColorToken(order.status)) {
                                                    Text(order.status, modifier = Modifier.padding(2.dp), fontSize = 10.sp, color = Color.White)
                                                }
                                                Text("رمز الطلب: ${order.orderNumber}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                            }

                                            Text("العناصر المشتراة: ${order.itemsJson}", fontSize = 11.sp, color = Color.DarkGray)
                                            Text("تكلفة التوصيل: ${order.shippingCost} ر.س", fontSize = 10.sp, color = Color.Gray)
                                            Text("المجموع النهائي: ${order.totalAmount} ر.س", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        // Wishlist list
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (wishlistedProducts.isEmpty()) {
                                item {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(imageVector = Icons.Default.Favorite, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(54.dp))
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text("مفضلتك خالية. فضلّ بعض المنتجات لتظهر هنا!", color = Color.Gray, fontSize = 13.sp)
                                        }
                                    }
                                }
                            } else {
                                items(wishlistedProducts) { prod ->
                                    Card(
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .frostedGlass(RoundedCornerShape(16.dp))
                                            .clickable { onNavigateToProduct(prod.id) }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            IconButton(onClick = { viewModel.toggleWishlist(prod.id) }) {
                                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.5f))
                                            }
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("${prod.price} ر.س", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                                Text(prod.condition, fontSize = 10.sp, color = Color.Gray)
                                            }
                                            Text(prod.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Right)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // Editable personal details formulation
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = editName,
                                onValueChange = { editName = it },
                                label = { Text("الاسم الكريم الكامل") },
                                modifier = Modifier.fillMaxWidth().testTag("profile_name_edit")
                            )

                            OutlinedTextField(
                                value = editPhone,
                                onValueChange = { editPhone = it },
                                label = { Text("رقم جوال المستلم") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = editEmail,
                                onValueChange = { editEmail = it },
                                label = { Text("البريد الإلكتروني") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = editAddress,
                                onValueChange = { editAddress = it },
                                label = { Text("عنوان التوصيل الافتراضي") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Button(
                                onClick = {
                                    if (editName.isNotEmpty() && editPhone.isNotEmpty()) {
                                        viewModel.updateUserProfile(
                                            UserProfile(
                                                name = editName,
                                                phone = editPhone,
                                                email = editEmail,
                                                address = editAddress,
                                                province = userProfile.province,
                                                city = userProfile.city,
                                                isLoggedIn = true
                                            )
                                        )
                                        Toast.makeText(context, "تم حفظ وتحديث بيانات حسابك الفنية بنجاح!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.align(Alignment.End).testTag("save_profile_edit_btn")
                            ) {
                                Text("حفظ التغييرات")
                            }
                        }
                    }
                }
            }
        }
    }
}

fun getStatusColorToken(status: String): Color {
    return when (status) {
        "قيد المراجعة" -> Color(0xFFFF8F00)
        "تم التأكيد" -> Color(0xFF1E88E5)
        "جاري الشحن" -> Color(0xFF7B1FA2)
        "تم التوصيل" -> Color(0xFF43A047)
        else -> Color.DarkGray
    }
}

package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Product
import com.example.ui.MainViewModel
import com.example.ui.theme.frostedGlass

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoriesScreen(
    viewModel: MainViewModel,
    initialCategory: String?,
    onNavigateToProduct: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val products by viewModel.products.collectAsState()
    val brands by viewModel.brands.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val wishlist by viewModel.wishlist.collectAsState()

    // Filter controls
    var currentCat by remember { mutableStateOf(initialCategory ?: "الكل") }
    var currentBrand by remember { mutableStateOf<String?>(null) }
    var currentCondition by remember { mutableStateOf("الكل") } // "الكل", "جديد", "مستعمل"
    var showInStockOnly by remember { mutableStateOf(false) }
    var showWithDiscountOnly by remember { mutableStateOf(false) }
    var minPrice by remember { mutableStateOf(0f) }
    var maxPrice by remember { mutableStateOf(6000f) }

    var expandedFilters by remember { mutableStateOf(false) }

    // Filter Logic
    val filteredProducts = remember(products, currentCat, currentBrand, currentCondition, showInStockOnly, showWithDiscountOnly, minPrice, maxPrice) {
        products.filter { prod ->
            val catMatch = currentCat == "الكل" || prod.category == currentCat
            val brandMatch = currentBrand == null || prod.brand.lowercase() == currentBrand?.lowercase()
            val condMatch = currentCondition == "الكل" || prod.condition == currentCondition
            val stockMatch = !showInStockOnly || prod.stockQuantity > 0
            val discMatch = !showWithDiscountOnly || prod.discountPercent > 0
            val priceMatch = prod.price >= minPrice && prod.price <= maxPrice
            catMatch && brandMatch && condMatch && stockMatch && discMatch && priceMatch
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("تصفح المنتجات والأقسام", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent
                ),
                actions = {
                    IconButton(onClick = { expandedFilters = !expandedFilters }) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = "Filters",
                            tint = if (expandedFilters) MaterialTheme.colorScheme.primary else Color.Gray
                        )
                    }
                }
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Slider of categories
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = currentCat == "الكل",
                        onClick = { currentCat = "الكل" },
                        label = { Text("الكل") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
                items(categories) { cat ->
                    FilterChip(
                        selected = currentCat == cat.name,
                        onClick = { currentCat = cat.name },
                        label = { Text(cat.name) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // Expanding advanced filters panel
            AnimatedVisibility(
                visible = expandedFilters,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .frostedGlass(RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("خيارات الفلترة المتقدمة", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)

                        // Brands Row
                        Column {
                            Text("الشركة المصنعة", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
                            LazyRow(
                                modifier = Modifier.padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                item {
                                    SuggestionChip(
                                        onClick = { currentBrand = null },
                                        label = { Text("الكل") },
                                        colors = SuggestionChipDefaults.suggestionChipColors(
                                            containerColor = if (currentBrand == null) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent
                                        )
                                    )
                                }
                                items(brands) { brand ->
                                    SuggestionChip(
                                        onClick = { currentBrand = brand.name },
                                        label = { Text(brand.name) },
                                        colors = SuggestionChipDefaults.suggestionChipColors(
                                            containerColor = if (currentBrand == brand.name) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent
                                        )
                                    )
                                }
                            }
                        }

                        // Product Condition: New vs Used
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("حالة الجهاز", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("الكل", "جديد", "مستعمل").forEach { cond ->
                                    ElevatedFilterChip(
                                        selected = currentCondition == cond,
                                        onClick = { currentCondition = cond },
                                        label = { Text(cond) }
                                    )
                                }
                            }
                        }

                        // Price Slider Range
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("السعر الأقصى: ${maxPrice.toInt()} ر.س", fontSize = 11.sp, color = Color.Gray)
                                Text("السعر الأدنى: ${minPrice.toInt()} ر.س", fontSize = 11.sp, color = Color.Gray)
                            }
                            Slider(
                                value = maxPrice,
                                onValueChange = { maxPrice = it },
                                valueRange = 0f..6000f,
                                modifier = Modifier.fillMaxWidth(),
                                colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.primary, activeTrackColor = MaterialTheme.colorScheme.primary)
                            )
                        }

                        // Switches for InStock and Discount
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("بالمخزون فقط", fontSize = 11.sp)
                                Switch(
                                    checked = showInStockOnly,
                                    onCheckedChange = { showInStockOnly = it },
                                    modifier = Modifier.scaleScaleOfSwitch()
                                )
                            }
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("عليه خصم فقط", fontSize = 11.sp)
                                Switch(
                                    checked = showWithDiscountOnly,
                                    onCheckedChange = { showWithDiscountOnly = it },
                                    modifier = Modifier.scaleScaleOfSwitch()
                                )
                            }
                        }

                        // Reset button
                        TextButton(
                            onClick = {
                                currentBrand = null
                                currentCondition = "الكل"
                                showInStockOnly = false
                                showWithDiscountOnly = false
                                minPrice = 0f
                                maxPrice = 6000f
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("إعادة تعيين", color = Color.Red, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Products Grid
            if (filteredProducts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(54.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("لا يوجد منتجات تطابق خيارات الفلترة المحددة.", color = Color.Gray, fontSize = 14.sp)
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredProducts) { prod ->
                        Box(modifier = Modifier.padding(4.dp)) {
                            ProductCardCompact(
                                product = prod,
                                isFavorite = wishlist.contains(prod.id),
                                onFavToggle = { viewModel.toggleWishlist(prod.id) },
                                onClick = { onNavigateToProduct(prod.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

// Simple modifier helper to scale down switch for compact layouts
private fun Modifier.scaleScaleOfSwitch() = this.size(width = 44.dp, height = 24.dp)

package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Product
import com.example.ui.MainViewModel
import com.example.ui.theme.frostedGlass
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToProduct: (Int) -> Unit,
    onNavigateToCategory: (String) -> Unit,
    onNavigateToMaintenance: () -> Unit,
    modifier: Modifier = Modifier
) {
    val products by viewModel.products.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val wishlist by viewModel.wishlist.collectAsState()

    var searchQuery by remember { mutableStateOf("") }

    val popularProducts = remember(products) {
        products.filter { it.isPopular }
    }
    val lightningDeals = remember(products) {
        products.filter { it.isLightningDeal }
    }
    val usedProducts = remember(products) {
        products.filter { it.condition == "مستعمل" }
    }
    val accessories = remember(products) {
        products.filter { it.category != "هواتف جديدة" && it.category != "هواتف مستعملة" }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "موبايلي برو | Mobily Pro",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.isAdminLoggedIn.value = !viewModel.isAdminLoggedIn.value }) {
                        Icon(
                            imageVector = if (viewModel.isAdminLoggedIn.collectAsState().value) Icons.Default.AdminPanelSettings else Icons.Default.Lock,
                            contentDescription = "Admin Entry",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                actions = {
                    Badge(
                        containerColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Text(
                            text = "صيانة وتجارة",
                            color = Color.White,
                            modifier = Modifier.padding(4.dp),
                            fontSize = 11.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // Instant Smart Search Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        viewModel.searchQuery.value = it
                    },
                    placeholder = {
                        Text(
                            "ابحث عن هاتف، إكسسوار، أو قطعة غيار...",
                            textAlign = TextAlign.Right,
                            fontSize = 14.sp
                        )
                    },
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search icon",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(4.dp, RoundedCornerShape(12.dp))
                        .testTag("search_bar_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    singleLine = true
                )
            }

            // If user is searching, show dynamic floating results
            if (searchQuery.isNotEmpty()) {
                val filtered = products.filter {
                    it.name.contains(searchQuery, ignoreCase = true) ||
                            it.brand.contains(searchQuery, ignoreCase = true) ||
                            it.category.contains(searchQuery, ignoreCase = true)
                }
                Text(
                    text = "نتائج البحث لـ \"$searchQuery\": (${filtered.size})",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    fontWeight = FontWeight.Bold
                )

                if (filtered.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("عذراً، لم نجد نتائج مطابقة لبحثك.", color = Color.Gray)
                    }
                } else {
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filtered) { prod ->
                            ProductCardCompact(
                                product = prod,
                                isFavorite = wishlist.contains(prod.id),
                                onFavToggle = { viewModel.toggleWishlist(prod.id) },
                                onClick = { onNavigateToProduct(prod.id) }
                            )
                        }
                    }
                }
            }

            // Offers Slider Banner
            AnimatedOffersBanner()

            // Quick Category Shortcuts Row
            Text(
                text = "تسوق حسب الفئات",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
                color = MaterialTheme.colorScheme.onBackground
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { category ->
                    CategoryBadge(
                        categoryName = category.name,
                        iconName = category.iconName,
                        onClick = { onNavigateToCategory(category.name) }
                    )
                }
            }

            // Quick Maintenance CallToAction Banner
            MaintenanceCallToAction(onNavigateToMaintenance)

            // Lightning Deals Countdown List
            if (lightningDeals.isNotEmpty()) {
                LightningDealsHeader()
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    items(lightningDeals) { deal ->
                        ProductCardCompact(
                            product = deal,
                            isFavorite = wishlist.contains(deal.id),
                            onFavToggle = { viewModel.toggleWishlist(deal.id) },
                            onClick = { onNavigateToProduct(deal.id) }
                        )
                    }
                }
            }

            // Most Popular Products
            if (popularProducts.isNotEmpty()) {
                SectionHeader("المنتجات الأكثر مبيعاً") { onNavigateToCategory("الكل") }
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    items(popularProducts) { prod ->
                        ProductCardCompact(
                            product = prod,
                            isFavorite = wishlist.contains(prod.id),
                            onFavToggle = { viewModel.toggleWishlist(prod.id) },
                            onClick = { onNavigateToProduct(prod.id) }
                        )
                    }
                }
            }

            // Used Smartphones Section
            if (usedProducts.isNotEmpty()) {
                SectionHeader("الهواتف المستعملة (بضمان المتجر)") { onNavigateToCategory("هواتف مستعملة") }
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    items(usedProducts) { used ->
                        ProductCardCompact(
                            product = used,
                            isFavorite = wishlist.contains(used.id),
                            onFavToggle = { viewModel.toggleWishlist(used.id) },
                            onClick = { onNavigateToProduct(used.id) }
                        )
                    }
                }
            }

            // Premium Accessories
            if (accessories.isNotEmpty()) {
                SectionHeader("إكسسوارات وملحقات مميزة") { onNavigateToCategory("سماعات") }
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    items(accessories) { acc ->
                        ProductCardCompact(
                            product = acc,
                            isFavorite = wishlist.contains(acc.id),
                            onFavToggle = { viewModel.toggleWishlist(acc.id) },
                            onClick = { onNavigateToProduct(acc.id) }
                        )
                    }
                }
            }

            // Why Choose Mobily Pro Section
            WhyChooseMobilyPro()

            // FAQs Section
            FaqSection()

            // Space at the bottom
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun AnimatedOffersBanner() {
    val banners = listOf(
        "خصومات هائلة تصل إلى 30% على صيانة الشاشات الأصلية!",
        "احصل على كوبون خصم MOBILY10 لتجربة شراء استثنائية الأولى",
        "هواتف مستعملة فحص فني دقيق 100% مع ضمان المتجر الحقيقي"
    )

    var currentBannerIdx by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            currentBannerIdx = (currentBannerIdx + 1) % banners.size
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .height(130.dp)
            .shadow(6.dp, RoundedCornerShape(16.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary,
                        Color(0xFF0D47A1) // Royal Blue
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        // Ambient background glow shapes
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            contentAlignment = Alignment.TopEnd
        ) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.15f),
                modifier = Modifier.size(100.dp)
            )
        }

        AnimatedContent(
            targetState = currentBannerIdx,
            transitionSpec = {
                (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                    slideOutHorizontally { width -> -width } + fadeOut()
                )
            },
            label = "Offer banner animation"
        ) { index ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "عروض موبايلي برو الحصرية",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Light,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = banners[index],
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

@Composable
fun CategoryBadge(
    categoryName: String,
    iconName: String,
    onClick: () -> Unit
) {
    val icon = when (iconName) {
        "phone_android" -> Icons.Default.PhoneAndroid
        "phonelink_setup" -> Icons.Default.MobileFriendly
        "headphones" -> Icons.Default.Headphones
        "watch" -> Icons.Default.Watch
        "bolt" -> Icons.Default.Bolt
        "battery_charging_full" -> Icons.Default.BatteryChargingFull
        "style" -> Icons.Default.Style
        "sports_esports" -> Icons.Default.SportsEsports
        "tablet_android" -> Icons.Default.TabletAndroid
        else -> Icons.Default.Build
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .padding(vertical = 4.dp)
            .frostedGlass(RoundedCornerShape(16.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = icon, contentDescription = categoryName, modifier = Modifier.size(20.dp))
            Text(
                text = categoryName,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun MaintenanceCallToAction(onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .frostedGlass(RoundedCornerShape(24.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .background(Color.Transparent),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Construction,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "تعطل هاتفك؟ صيانة احترافية فورية!",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "شاشات أصلية، بطاريات بضمان، فك حسابات، علاج مشاكل الشحن والماء بأيدي مهندسين مختصين.",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    lineHeight = 16.sp
                )
            }

            Icon(
                imageVector = Icons.Default.ArrowForwardIos,
                contentDescription = "Details",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun LightningDealsHeader() {
    var timerSeconds by remember { mutableStateOf(43200) } // 12 hours countdown initial

    LaunchedEffect(Unit) {
        while (timerSeconds > 0) {
            delay(1000)
            timerSeconds--
        }
    }

    val hours = timerSeconds / 3600
    val minutes = (timerSeconds % 3600) / 60
    val seconds = timerSeconds % 60

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.FlashOn,
                contentDescription = "Lightning deal",
                tint = Color(0xFFFFB300)
            )
            Text(
                text = "عروض البرق الخاطفة",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Countdown Timer Clock
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TimeBox(value = String.format("%02d", hours))
            Text(":", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            TimeBox(value = String.format("%02d", minutes))
            Text(":", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            TimeBox(value = String.format("%02d", seconds))
        }
    }
}

@Composable
fun TimeBox(value: String) {
    Box(
        modifier = Modifier
            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = value,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun SectionHeader(title: String, onSeeAllClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 20.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        TextButton(onClick = onSeeAllClick) {
            Text(
                text = "عرض الكل",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun ProductCardCompact(
    product: Product,
    isFavorite: Boolean,
    onFavToggle: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(165.dp)
            .frostedGlass(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("product_${product.id}_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Placeholder Image with customized gradients
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.05f),
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Determine icon based on category
                val icon = if (product.category == "سماعات") Icons.Default.Headphones
                else if (product.category == "ساعات ذكية") Icons.Default.Watch
                else if (product.category == "شواحن" || product.category == "باور بانك") Icons.Default.Bolt
                else if (product.category == "قطع غيار") Icons.Default.Build
                else Icons.Default.Smartphone

                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                    modifier = Modifier.size(50.dp)
                )

                ImageOverlayShadow()
            }

            // Discount Badge
            if (product.discountPercent > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .background(Color(0xFFE53935), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "خصم ${product.discountPercent}%",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Condition Tag
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .background(
                        if (product.condition == "جديد") Color(0xFF43A047) else Color(0xFF1E88E5),
                        RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = product.condition,
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Wishlist Toggle Button
            IconButton(
                onClick = onFavToggle,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
            ) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Wishlist Toggle",
                    tint = if (isFavorite) Color.Red else Color.LightGray,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Product Info Text
        Column(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = product.name,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )

            // Rating Star
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(12.dp))
                Text(
                    text = "${product.rating}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                Text(
                    text = "(${product.reviewCount})",
                    fontSize = 9.sp,
                    color = Color.LightGray
                )

                if (product.batteryHealth != null) {
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = "🔋 %${product.batteryHealth}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF43A047)
                    )
                }
            }

            // Price Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp)
            ) {
                Text(
                    text = "${product.price} ر.س",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                if (product.oldPrice > product.price) {
                    Text(
                        text = "${product.oldPrice}",
                        fontSize = 10.sp,
                        textDecoration = TextDecoration.LineThrough,
                        color = Color.LightGray
                    )
                }
            }
        }
    }
}

@Composable
fun ImageOverlayShadow() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.05f))
                )
            )
    )
}

@Composable
fun WhyChooseMobilyPro() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "لماذا تختار موبايلي برو؟",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Verified, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                    Text("ضمان حقيقي", fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center)
                    Text("جميع منتجاتنا وخدمات الصيانة مشمولة بضمانات معتمدة.", fontSize = 9.sp, color = Color.Gray, textAlign = TextAlign.Center, lineHeight = 12.sp)
                }

                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(32.dp))
                    Text("سرعة الإنجاز", fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center)
                    Text("صيانة سريعة وتسليم فوري وهواتفنا المستعملة مفحوصة بدقة.", fontSize = 9.sp, color = Color.Gray, textAlign = TextAlign.Center, lineHeight = 12.sp)
                }

                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.SupportAgent, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                    Text("دعم فني مستمر", fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center)
                    Text("فريق خدمة العملاء جاهز للرد والإجابة على استفساراتكم.", fontSize = 9.sp, color = Color.Gray, textAlign = TextAlign.Center, lineHeight = 12.sp)
                }
            }
        }
    }
}

@Composable
fun FaqSection() {
    val faqs = listOf(
        "ما هو الفرق بين الهواتف المجددة والمستعملة؟" to "المستعمل يباع بحالته الأصلية بعد اجتياز فحص فني دقيق من 25 نقطة، بينما المجدد قد يحتوي قطع غيار مستبدلة.",
        "هل يوجد توصيل للمحافظات وخيارات مختلفة؟" to "نعم، نوفر خدمات التوصيل السريع لكافة المحافظات بتكلفة شحن مدروسة تحسب آلياً بحسب موقعك.",
        "كم يستغرق فحص وإصلاح الهواتف بقسم الصيانة؟" to "غالب عيوب الشاشات والبطاريات تستغرق ساعة واحدة فقط، بينما الأعطال المعقدة في اللوحة الأم قد تستغرق من يوم إلى ٣ أيام كحد أقصى."
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "الأسئلة الشائعة",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        faqs.forEach { (q, a) ->
            var expanded by remember { mutableStateOf(false) }
            Card(
                onClick = { expanded = !expanded },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = q,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Right
                        )
                        Icon(
                            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = Color.Gray
                        )
                    }

                    if (expanded) {
                        Text(
                            text = a,
                            fontSize = 11.sp,
                            color = Color.DarkGray,
                            lineHeight = 16.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

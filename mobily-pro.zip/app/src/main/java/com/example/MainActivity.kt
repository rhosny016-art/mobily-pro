package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NamedNavArgument
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.ui.MainViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.frostedGlass
import com.example.ui.theme.premiumBackground

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val mainViewModel: MainViewModel = viewModel()
                MobilyProApp(viewModel = mainViewModel)
            }
        }
    }
}

@Composable
fun MobilyProApp(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val cart by viewModel.cart.collectAsState()
    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsState()

    // Determine configuration screen classes (Tablet / Landscape vs phone Portrait)
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    // Keep track of active bottom navigation route
    var currentSelectedRoute by remember { mutableStateOf("home") }

    val cartBadgeCount = remember(cart) {
        cart.values.sum()
    }

    Row(modifier = Modifier.fillMaxSize()) {
        if (isTablet) {
            // Adaptive design: Sidebar Navigation Rail on Wide screen
            NavigationRail(
                containerColor = Color.Transparent,
                modifier = Modifier
                    .fillMaxHeight()
                    .frostedGlass(RoundedCornerShape(0.dp))
                    .testTag("tablet_nav_rail"),
                header = {
                    Icon(
                        imageVector = Icons.Default.Smartphone,
                        contentDescription = "Mobily Pro Logo",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            ) {
                NavigationRailItem(
                    selected = selectRouteMatches(currentSelectedRoute, "home"),
                    onClick = {
                        currentSelectedRoute = "home"
                        navController.navigate("home")
                    },
                    icon = { Icon(Icons.Default.Storefront, contentDescription = "Home") },
                    label = { Text("الرئيسية") }
                )

                NavigationRailItem(
                    selected = selectRouteMatches(currentSelectedRoute, "categories"),
                    onClick = {
                        currentSelectedRoute = "categories"
                        navController.navigate("categories")
                    },
                    icon = { Icon(Icons.Default.Category, contentDescription = "Categories") },
                    label = { Text("الفئات") }
                )

                NavigationRailItem(
                    selected = selectRouteMatches(currentSelectedRoute, "maintenance"),
                    onClick = {
                        currentSelectedRoute = "maintenance"
                        navController.navigate("maintenance")
                    },
                    icon = { Icon(Icons.Default.Build, contentDescription = "Maintenance") },
                    label = { Text("الصيانة") }
                )

                NavigationRailItem(
                    selected = selectRouteMatches(currentSelectedRoute, "cart"),
                    onClick = {
                        currentSelectedRoute = "cart"
                        navController.navigate("cart")
                    },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (cartBadgeCount > 0) {
                                    Badge { Text("$cartBadgeCount") }
                                }
                            }
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = "Cart")
                        }
                    },
                    label = { Text("السلة") }
                )

                NavigationRailItem(
                    selected = selectRouteMatches(currentSelectedRoute, "profile"),
                    onClick = {
                        currentSelectedRoute = "profile"
                        navController.navigate("profile")
                    },
                    icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Profile") },
                    label = { Text("حسابي") }
                )
            }
        }

        Scaffold(
            bottomBar = {
                if (!isTablet) {
                    // Mobile Bottom Navigation Bar with RTL direction Support
                    NavigationBar(
                        containerColor = Color.Transparent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .frostedGlass(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                            .testTag("mobile_bottom_nav")
                    ) {
                        NavigationBarItem(
                            selected = selectRouteMatches(currentSelectedRoute, "profile"),
                            onClick = {
                                currentSelectedRoute = "profile"
                                navController.navigate("profile")
                            },
                            icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Profile") },
                            label = { Text("حسابي", fontSize = 11.sp) }
                        )

                        NavigationBarItem(
                            selected = selectRouteMatches(currentSelectedRoute, "cart"),
                            onClick = {
                                currentSelectedRoute = "cart"
                                navController.navigate("cart")
                            },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (cartBadgeCount > 0) {
                                            Badge { Text("$cartBadgeCount") }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.ShoppingCart, contentDescription = "Cart")
                                }
                            },
                            label = { Text("السلة", fontSize = 11.sp) }
                        )

                        NavigationBarItem(
                            selected = selectRouteMatches(currentSelectedRoute, "maintenance"),
                            onClick = {
                                currentSelectedRoute = "maintenance"
                                navController.navigate("maintenance")
                            },
                            icon = { Icon(Icons.Default.Build, contentDescription = "Maintenance") },
                            label = { Text("الصيانة", fontSize = 11.sp) }
                        )

                        NavigationBarItem(
                            selected = selectRouteMatches(currentSelectedRoute, "categories"),
                            onClick = {
                                currentSelectedRoute = "categories"
                                navController.navigate("categories")
                            },
                            icon = { Icon(Icons.Default.Category, contentDescription = "Categories") },
                            label = { Text("الفئات", fontSize = 11.sp) }
                        )

                        NavigationBarItem(
                            selected = selectRouteMatches(currentSelectedRoute, "home"),
                            onClick = {
                                currentSelectedRoute = "home"
                                navController.navigate("home")
                            },
                            icon = { Icon(Icons.Default.Storefront, contentDescription = "Home") },
                            label = { Text("الرئيسية", fontSize = 11.sp) }
                        )
                    }
                }
            },
            modifier = Modifier.weight(1f)
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .premiumBackground()
                    .padding(innerPadding)
            ) {
                // If admin logs in, swap screen or overlay the dashboard completely so they don't lose context
                if (isAdminLoggedIn) {
                    AdminDashboardScreen(
                        viewModel = viewModel,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    NavHost(
                        navController = navController,
                        startDestination = "home",
                        modifier = Modifier.fillMaxSize()
                    ) {
                        composable("home") {
                            HomeScreen(
                                viewModel = viewModel,
                                onNavigateToProduct = { pid -> navController.navigate("product/$pid") },
                                onNavigateToCategory = { catName -> navController.navigate("categories?category=$catName") },
                                onNavigateToMaintenance = {
                                    currentSelectedRoute = "maintenance"
                                    navController.navigate("maintenance")
                                }
                            )
                        }

                        composable(
                            route = "categories?category={category}",
                            arguments = listOf(
                                navArgument("category") {
                                    type = NavType.StringType
                                    nullable = true
                                    defaultValue = null
                                }
                            )
                        ) { backStackEntry ->
                            val cat = backStackEntry.arguments?.getString("category")
                            CategoriesScreen(
                                viewModel = viewModel,
                                initialCategory = cat,
                                onNavigateToProduct = { pid -> navController.navigate("product/$pid") }
                            )
                        }

                        composable(
                            route = "product/{id}",
                            arguments = listOf(
                                navArgument("id") { type = NavType.IntType }
                            )
                        ) { backStackEntry ->
                            val pid = backStackEntry.arguments?.getInt("id") ?: 1
                            ProductDetailsScreen(
                                viewModel = viewModel,
                                productId = pid,
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToProduct = { newPid -> navController.navigate("product/$newPid") },
                                onNavigateToCart = {
                                    currentSelectedRoute = "cart"
                                    navController.navigate("cart")
                                }
                            )
                        }

                        composable("maintenance") {
                            MaintenanceScreen(viewModel = viewModel)
                        }

                        composable("cart") {
                            CartScreen(
                                viewModel = viewModel,
                                onNavigateToHome = {
                                    currentSelectedRoute = "home"
                                    navController.navigate("home")
                                }
                            )
                        }

                        composable("profile") {
                            ProfileScreen(
                                viewModel = viewModel,
                                onNavigateToProduct = { pid -> navController.navigate("product/$pid") }
                            )
                        }
                    }
                }
            }
        }
    }
}

fun selectRouteMatches(curr: String, match: String): Boolean = curr == match

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
